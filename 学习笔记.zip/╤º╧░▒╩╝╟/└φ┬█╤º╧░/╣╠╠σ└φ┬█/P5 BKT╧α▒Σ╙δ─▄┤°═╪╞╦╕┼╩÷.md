# BKT 相变  
# 整数量子霍尔效应
# 分数量子霍尔效应
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202404251650260.png)
- 由于布里渊区上边和下边等价，左边和右边等价，故可以连在一起。
- 霍尔电导是贝利曲率在整个布里渊区上的积分
# Haldane 模型
# 拓扑半金属与拓扑绝缘体
