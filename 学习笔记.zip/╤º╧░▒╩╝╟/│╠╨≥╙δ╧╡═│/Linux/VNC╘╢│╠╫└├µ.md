- 启动 VNC Server
```
vncserver
```
- 创建监听窗口
```
vncserver -localhost no
```
- 查看 VNC 会话
```
vncserver -list
```
- 关闭某个会话
```
vncserver -kill :1
```