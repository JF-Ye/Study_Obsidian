# 概览
- 官网：[EPW Software (epw-code.org)](https://epw-code.org/)
- 官网 school 有很多具体例子：[Summer School 2024 — EPW documentation](https://docs.epw-code.org/doc/School2024.html)
- 教程：[QUANTUM ESPRESSO：EPW - 谢华的博客 | Xiehua's Blog (xh125.github.io)](https://xh125.github.io/2021/12/16/QE-epw/)
- 教程 2：[qe-study](https://github.com/nawu97/qe-study/blob/main/Wed.4.Verdi.pdf)
- 官网参数说明：[点击这里](https://docs.epw-code.org/doc/Inputs.html#inputepw)
- 能做什么？
> 1. 超导特性
> 2. 不同温度下的能带结构
> 3. 输运性质和热载流子动力学

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202407192041003.png)
# 一、SCF 自洽计算
# 二、`ph.x` 声子谱计算
# 三、`pp.py` 提取 `.dvscf` 和 `.dyn` 文件到save文件夹
# 四、创建 epw 新目录进行 SCF 计算
# 五、进行 nscf 计算
# 六、进行 EPW 计算
- 核心：计算布里渊区每个不可约 q 点的（k, k+q）点的*电-声耦合矩阵*，并利用对称性展开到整个布里渊区
## 控制参数
### amass：原子质量
- 不设则从文件中读取
### ep_coupling：运行电声耦合计算
- Default：.true.
### elph：计算电声耦合系数
- Default：. False.
### epbwrite：输出电声矩阵和 dyn 矩阵的 `.epb`  文件
- Default：.false.
### epbread：读取 `.epb` 文件
- Default：.false.
### epwwrite：输出电声矩阵和 dyn 矩阵的文件
- Default：.true.
### epwread：从 `epwdata.fmt` 和 `XX.epmatwpX` 中读取电声矩阵
- Default：.false.
- 用于重启计算，同时还要设 `kmaps=.true.` 
### etf_mem：控制内存参数
- Default：1
- **`etf_mem=1`**：电声矩阵存储于内存中，计算更快
- **`etf_mem=2`**：更少内存
### iverbosity：超导参数调控
- 0：default，短输出
- 1：详细输出
- 2：超导部分详细输出
- 3：仅针对电声部分详细输出
## Wannier 90 参数
### nbndsub：需要 wannier 函数的数量
- Default：0
- 等价于 `num_wann`
### wannierize：计算 wannier 函数
- Default：.false.
- 输出 wannier 矩阵文件 `.filukk
### num_iter：参考 wannier 90 计算
### dis_froz_min 和 dis_froz_max：参考 wannier90 计算
- 跟 wannier 90 一样的设置参数方法，不过要注意费米能级
### proj (i)
## 计算标准参数
### eps_acustic
### ephwrite 
### fsthick：费米表面窗口宽度
- Default：1.d10 
- 单位：eV
- 推荐设置：`fsthick = 4 × 最大声子频率`
- 最大声子频率看声子谱最大值，转换为 eV 单位。后面几个参数同理
### wscut：Eliashberg 方程的频率积分上限
- Default：1.d0
- 单位：eV
- 推荐设置：`wscut = 10 × 最大声子频率`
### muc
- 推荐设置：0.1~0.2
### degaussw：能量函数的展宽
- Default：0.025
- 单位：eV
- 推荐设置：`degaussw = 1/4 × fsthick`
### degaussq：电声耦合的展宽
- Default：0.05
### nsmear
### delta_smear

### nqstep
### eliashberg
### laniso
### limag
### lpade
### conv_thr_iaxis
### nstemp
### temps
### nsiter
### dvscf_dir
### nk1：粗网格
### nq1
### mp_mesh_k
### nkf1：精细网格
### nqf1
## 范例
```
--
&inputepw
  prefix      = 'MgB2',
  amass(1)    = 24.305,
  amass(2)    = 10.811
  outdir      = './'

  ep_coupling = .true.
  elph        = .true.
  epbwrite    = .true.
  epbread     = .false.

  epwwrite = .true.
  epwread  = .false.

  etf_mem     =  1 

  nbndsub     =  5,

  wannierize  = .true.
  num_iter    = 500
  dis_froz_max= 8.8
  proj(1)     = 'B:pz'
  proj(2)     = 'f=0.5,1.0,0.5:s'
  proj(3)     = 'f=0.0,0.5,0.5:s'
  proj(4)     = 'f=0.5,0.5,0.5:s'

  iverbosity  = 2

  eps_acustic = 2.0    
  ephwrite    = .true. 

  fsthick     = 0.4  ! eV
  degaussw    = 0.10 ! eV
  nsmear      = 1
  delta_smear = 0.04 ! eV

  degaussq     = 0.5 ! meV
  nqstep       = 500
  
  eliashberg  = .true.

  laniso = .true.
  limag = .true.
  lpade = .true.

  conv_thr_iaxis = 1.0d-4

  wscut = 1.0   ! eV  

  nstemp   = 1     ! Nr. of temps
  temps    = 15.00 

  nsiter   = 500

  muc     = 0.16

  dvscf_dir   = '../phonons/save'
  
  nk1         = 6
  nk2         = 6
  nk3         = 6

  nq1         = 6
  nq2         = 6
  nq3         = 6

  mp_mesh_k = .true.
  nkf1 = 20
  nkf2 = 20
  nkf3 = 20

  nqf1 = 20
  nqf2 = 20
  nqf3 = 20
```

