[渐变色生成器-在线生成CSS渐变色工具](https://www.lingdaima.com/jianbianse/)
生成 HTML 代码
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412232001977.png)
Matlab 代码生成 rgb 文件
```matlab
	positions = [0, 0.04, 0.13, 0.37, 1]; % 关键点的位置 (0 到 1 的比例)
	colors = [
		2, 0, 36; % rgba(2,0,36,1)
		136, 41, 142; % rgba(136,41,142,1)
		198, 62, 75; % rgba(198,62,75,1)
		244, 123, 20; % rgba(244,123,20,1)
		251, 252, 162 % rgba(251,252,162,1)
	] / 255; % 将 RGB 值归一化到 [0,1]
	
	% 定义渐变的分辨率
	nColors = 256; % 渐变的颜色数量
	
	gradientPositions = linspace(0, 1, nColors);
	
	% 使用线性插值生成渐变颜色
	gradientColors = zeros(nColors, 3);
	for i = 1:3
		gradientColors(:, i) = interp1(positions, colors(:, i), gradientPositions, 'linear');	
	end
	
	% 将 RGB 值保存到文件
	rgbFileName = 'colormap.rgb';
	fileID = fopen(rgbFileName, 'w');
	fprintf(fileID, 'ncolors= %d\n', nColors);
	fprintf(fileID, 'R G B\n');
	for i = 1:size(gradientColors, 1)
		fprintf(fileID, '%.6f %.6f %.6f\n', gradientColors(i, :));
	end
	fclose(fileID);

```
