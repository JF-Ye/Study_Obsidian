```wt.in
&CONTROL
Boltz_OHE_calc = T
/

&PARAMETERS
EF_integral_range = 0.05  ! in eV used to define the energy range around fermi energy in calculating sigma_OHE
/
```