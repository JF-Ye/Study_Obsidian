[自然—通讯：观测到二维极性材料中光学声子的奇异行为 - 知乎 (zhihu.com)](https://zhuanlan.zhihu.com/p/686095197)
Observation of the nonanalytic behavior of optical phonons in monolayer hexagonal boron nitride
光学声子对材料的光、电、热等物理性质起着至关重要的作用。特别是，纵向光学（LO）声子的行为由于材料的[极性](https://zhida.zhihu.com/search?q=%E6%9E%81%E6%80%A7&zhida_source=entity&is_preview=1)而与众不同。在非极性材料中，无论是三维（3D）还是二维（2D）系统，晶格对称性保证了LO和横向光学（TO）声子在布里渊区中心具有零色散斜率的简并（图1a）。然而，在极性材料中，LO声子的[晶格振动](https://zhida.zhihu.com/search?q=%E6%99%B6%E6%A0%BC%E6%8C%AF%E5%8A%A8&zhida_source=entity&is_preview=1)会产生额外的长程电场，进而对极性晶格施加长程[库仑力](https://zhida.zhihu.com/search?q=%E5%BA%93%E4%BB%91%E5%8A%9B&zhida_source=entity&is_preview=1)。
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412232318588.png)
