1. 电子如何诱导轨道角动量：通过轨道和晶格相互作用
2. 轨道角动量如何再晶格中传播？
3. 轨道角动量如何将角动量传递给自旋？

[wannier_tools/useful_scripts/post_sigma_OHE/post_sigma_OHE.py at master · quanshengwu/wannier_tools · GitHub](https://github.com/quanshengwu/wannier_tools/blob/master/useful_scripts/post_sigma_OHE/post_sigma_OHE.py)