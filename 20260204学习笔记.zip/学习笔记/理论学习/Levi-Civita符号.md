$$\epsilon _{ijk}=\left\{ \begin{array}{l}
	1&		(i,j,k)\in \{(1,2,3),(2,3,1),(3,1,2)\}\\
	-1&		(i,j,k)\in \{(3,2,1),(2,1,3),(1,3,2)\}\\
	0&		\,\,\text{其它，有两个相同则为0}\\
\end{array} \right. $$