# 一、内容
[利用Wannier90的hr数据构建动量空间能带并计算高对称点宇称 - Yu-Xuan Blog](https://yxli8023.github.io/2021/12/07/HRToHK.html)
```
 written on 27Dec2023 at 11:10:34 
         100    ! num_wann数，能带数， 矩阵维度，跟有多少个轨道跃迁有关
         729	! 晶格矢量的个数
    2    1    1    1    1    1    2    2    1    1    1    1    1    2    2
    1    1    1    1    1    2    2    1    1    1    1    1    2    2    1
    1    1    1    1    2    2    1    1    1    1    1    2    2    1    1
    1    1    1    2    2    1    1    1    1    1    2    2    1    1    1
    1    1    2    2    1    1    1    1    1    2    2    1    1    1    1
    1    2    2    1    1    1    1    1    2    2    1    1    1    1    1
    2    2    1    1    1    1    1    2    2    1    1    1    1    1    2
    2    1    1    1    1    1    2    2    1    1    1    1    1    2    2
    1    1    1    1    1    2    2    1    1    1    1    1    2    2    1
    1    1    1    1    2    2    1    1    1    1    1    2    2    1    1
    1    1    1    2    2    1    1    1    1    1    2    2    1    1    1
    1    1    2    2    1    1    1 .....（729个数）	！能带兼并情况
   -3   -2   -3    1 Ca-dxy    1 Ca-dxy   0.007585 实部  -0.000000 虚部
   -3   -2   -3    2 Ca-dxy    1 Ca-dxy  -0.002188    0.000000
   -3   -2   -3    3 Ca-dxz   1 Ca-dxy  -0.000922    0.000000
   -3   -2   -3    4 Ca-dxz   1 Ca-dxy   0.000533   -0.000000
   -3   -2   -3    5 Ca-dz2   1 Ca-dxy  -0.000385   -0.000000
   -3   -2   -3    6 Ca-dz2   1 Ca-dxy   0.000649   -0.000000
   -3   -2   -3    7 Ca-dyz   1 ...  -0.029399    0.000000
   -3   -2   -3    8 Ca-dyz   1    0.002602    0.000000
   -3   -2   -3    9 Ca-dx2-y2   1   -0.000000   -0.000000
   -3   -2   -3   10 Ca-dx2-y2   1   -0.000014    0.000000
   -3   -2   -3   11 Pd1-s   1   -0.000050    0.000000
   -3   -2   -3   12 Pd1-s   1    0.000000    0.000000
   -3   -2   -3   13 Pd1-px   1    0.011457   -0.000000
   -3   -2   -3   14 Pd1-px   1   -0.001038   -0.000000
   -3   -2   -3   15 Pd1-pz   1   -0.000000   -0.000000
   -3   -2   -3   16 Pd1-pz   1    0.001176    0.000000
   -3   -2   -3   17 Pd1-py   1   -0.002319   -0.000000
   -3   -2   -3   18 Pd1-py  1    0.000000   -0.000000
   -3   -2   -3   19 Pd1-dxy   1    0.011463   -0.000000
   -3   -2   -3   20 Pd1-dxy   1   -0.001046   -0.000000
   -3   -2   -3   21 Pd1-dxz  1    0.001021    0.000000
   -3   -2   -3   22 Pd1-dxz   1   -0.000589    0.000000
   -3   -2   -3   23 Pd1-dz2   1    0.001107    0.000000
   -3   -2   -3   24 Pd1-dz2   1   -0.001980   -0.000000
   -3   -2   -3   25 Pd1-dyz   1   -0.009142    0.000000
   -3   -2   -3   26 Pd1-dyz   1   -0.000030   -0.000000
   -3   -2   -3   27 Pd1-dx2-y2   1   -0.005518   -0.000000
   -3   -2   -3   28 Pd1-dx2-y2   1    0.000619    0.000000
   -3   -2   -3   29 Pd2-s     1   -0.002643    0.000000
   -3   -2   -3   30 Pd2-s    1 Ca-dxy  -0.002643    0.000000
```
- 前三列表示胞间跃迁，0 0 0 表示原胞， 1 0 0 表示沿 x 轴扩一胞
- 1-100 分别表示：(投影   Ca: d    Pd: s, p, d)
	- 1-10: Ca-dxy, Ca-dxz, Ca-dz2, Ca-dyz, Ca-dx2-y2 (加 soc * 2)
	- 11-12: Pd1-s
	- 13-18: Pd1-px, Pd1-pz, Pd1-py
	- 19-28: Pd1-dxy, Pd1-dxz, Pd1-dz2, Pd1-dyz, Pd1-dx2-y2
	- 29-30: Pd1-s
	- ........
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161040457.png)

公众号计算物理：“如何读取 wannier 90_hr. Dat 文件并将文件中的参数绘图”
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161058741.png)
```
fidt = fopen(hrfile);
fgetl(fidt);

tot_band = str2double(fgetl(fidt));
tot_hp = str2double(fgetl(fidt));
fclose(fidt);

hp_data = readmatrix("phonopyTB_hr.dat","FileType","text","NumHeaderLines",6);

hopping = zeros(1, 3, tot_hp);
for m = 1:tot_hp
hopping(:, :, m) = hp_data(1 + tot_band^2 * (m - 1), 1:3); % 提取了每个hopping的跃迁方向
end

hamiltonian=zeros(tot_band,tot_band,tot_hp);
for m=1:tot_hp
	for n=1:tot_band^2
		hamiltonian(hp_data(n+tot_band^2*(m-1),4),hp_data(n+tot_band^2*(m-1),5),m)=...
		hoppingdata(n+tot_band^2*(m-1),6)+1j*hoppingdata(n+nbands^2*(m-1),7);
		%
	end
end
```
![微信图片_20241216164104.jpg](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161641325.jpg)
- - -
## 关于 `ndegen`
- 含义：等价的晶格矢量 R 有多少个？
- 如果 **没有用任何空间群对称性**，每个 R 都是你自己枚举的，则都为 1
# 二、从哈密顿量出发构建 `wannier90_hr.dat` 文件 
## 1. 共线体系
- 紧束缚模型知识：[[0-构建紧束缚模型#一、倒空间 $H( mathbf{k})$、实空间 $H( mathbf{R})$ 的傅里叶转换|紧束缚模型公式笔记]]
- 构建哈密顿量方法用 [[0-构建紧束缚模型#方法二|方法二]]
- 核心：构建实空间的哈密顿量
$$H_{mn}(\mathbf{R})=\frac{1}{N_k}\sum_{\mathbf{k}}{H_{mn}(\mathbf{k})e^{-i\mathbf{k}\cdot \mathbf{R}}}$$
- **更具体而言**，实空间哈密顿量 $H_{mn}(\mathbf{R})$ 的形式为: 
$$H(\mathbf{R})=\left[ \begin{matrix}
	H\left( -110 \right)&		H\left( -100 \right)&		\cdots&		H\left( 110 \right)\\
\end{matrix} \right] $$
- 其中，$H\left( -110 \right)$ 是维度为 $3 \times 3$ 的矩阵（num_wann=3）：

$$H\left( -1 1 0 \right) _{3\times 3}=\frac{1}{N_k}\sum_{\mathbf{k}}{H(\mathbf{k})e^{-i\mathbf{k}\cdot \mathbf{R}}}\text{，}\mathbf{R}=\left( -1,1,0 \right) $$
- 每一个实空间 $H\left( -110 \right)_{3\times 3}$，都是整个布里渊区所有 k 点的“平均相干结果”
$$H\left( -1 1 0 \right) _{3\times 3}=\left( \begin{matrix}
	H_{aa}&		H_{ab}&		H_{ac}\\
	H_{ba}&		H_{bb}&		H_{bc}\\
	H_{ca}&		H_{cb}&		H_{cc}\\
\end{matrix} \right) $$
- 其中，$a$，$b$，$c$ 分别代表 3 个原子轨道
- $H_{ab}$ 表示从格点 $a$ 跃迁到格点 $b$ 的跃迁系数，是个**复数**
- 至此，我们得到了实空间沿 $(-100)$ 胞方向，从 a 跃迁至 b 的跃迁系数**实部**和**虚部**
- 具体代码：见 `00_程序脚本备份/create_hr.ipynb` [点击这里](file:///E:/Obsidian笔记/学习笔记/00_程序脚本备份/create_hr.ipynb)
```python
# =====================================================================
# 第五部分：傅里叶逆变换
# =====================================================================

def fourier_transform_to_real_space(R_list, kx_arr, ky_arr, kz_arr,
                                     a1, a2, a3, b1, b2, b3,
                                     num_wann, epsi, t1):
    """
    通过傅里叶逆变换计算实空间哈密顿量
    H(R) = (1/Nk) * Σ_k H(k) * e^(-ik·R)
    
    参数:
        R_list: 实空间格点列表
        kx_arr, ky_arr, kz_arr: k空间分数坐标数组
        a1, a2, a3: 实空间晶格矢量
        b1, b2, b3: 倒格矢量
        num_wann: Wannier函数数量
        epsi, t1: 哈密顿量参数
    
    返回:
        H_R: 实空间哈密顿量字典
    """
    H_R = {}
    
    print("开始傅里叶逆变换...")
    
    # 初始化所有R点的矩阵
    for R in R_list:
        H_R[R] = np.zeros((num_wann, num_wann), dtype=complex)
    
    # 计算总k点数
    k_grid_total = len(kx_arr) * len(ky_arr) * len(kz_arr)
    
    # 遍历k空间
    # 每一个R点的hopping，都是整个布里渊区所有k点的“平均相干结果”
    for kx_frac in kx_arr:
        for ky_frac in ky_arr:
            for kz_frac in kz_arr:
                k_vec = kx_frac * b1 + ky_frac * b2 + kz_frac * b3
                
                # 计算该k点的哈密顿量
                Hk = build_hamiltonian(k_vec, a1, a2, a3, epsi, t1)
                
                # 所有R点，都要保留该k点的影响
                for R in R_list:
                    R_vec = R[0] * a1 + R[1] * a2 + R[2] * a3
                    phase = np.exp(-1j * np.dot(k_vec, R_vec))
                    H_R[R] += Hk * phase
    
    # 归一化
    for R in R_list:
        H_R[R] /= k_grid_total
    
    print("傅里叶逆变换完成\n")
    
    return H_R
```


## 2. 非共线体系（num_wann=轨道数 $\times$ 2）
- 关键不同：更改哈密顿量即可
- $\times$ 2 部分的影响在于非共线体系的哈密顿量引入自旋空间单位矩阵
- 即 $H\left( -110 \right)$ 是维度为 $6 \times 6$ 的矩阵（num_wann=6）
- 具体代码：见 `00_程序脚本备份/create_hr_spinors.ipynb` [点击这里](file:///E:/Obsidian笔记/学习笔记/00_程序脚本备份/create_hr_spinors.ipynb)
# 三、从 `wannier90_hr.dat` 出发构建能带结构
- 核心：将哈密顿量从实空间转到倒空间
$$H_{mn}(\mathbf{k})=H_{mn}(\mathbf{R})\sum_{\mathbf{R}}{e^{i\mathbf{k}^{\prime}\cdot \mathbf{R}}}$$
- 核心代码
```python
# =====================================================================
# 第二部分：傅里叶变换
# =====================================================================

def H_from_HR(k_vec, H_R, R_list, a1, a2, a3):
    """
    从实空间哈密顿量 H(R) 通过傅里叶变换得到 H(k)
    H(k) = Σ_R H(R) * e^(ik·R)
    
    参数:
        k_vec: k空间向量
        H_R: 实空间哈密顿量字典
        R_list: 实空间格点列表
        a1, a2, a3: 实空间晶格矢量
    
    返回:
        Hk: k空间哈密顿量矩阵
    """
    num_wann = next(iter(H_R.values())).shape[0]
    Hk = np.zeros((num_wann, num_wann), dtype=complex)
    
    for R in R_list:
        R_vec = R[0]*a1 + R[1]*a2 + R[2]*a3
        phase = np.exp(1j * np.dot(k_vec, R_vec))
        Hk += H_R[R] * phase
    
    return Hk
```
- 得到哈密顿量后，求解高对称路径上哈密顿量的本征值，即可得到能带 
- 具体代码：见 `00_程序脚本备份/read_hr.ipynb` [点击这里](file:///E:/Obsidian笔记/学习笔记/00_程序脚本备份/read_hr.ipynb)