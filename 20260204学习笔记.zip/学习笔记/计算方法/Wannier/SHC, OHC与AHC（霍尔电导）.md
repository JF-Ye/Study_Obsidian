```
&CONTROL
AHC_calc=T     ! 反常霍尔电导
SHC_calc=T     ！自旋霍尔电导
/

&PARAMETERS
OmegaNum = 601    ! number of slices of energy
OmegaMin = -1.0   ! erergy range for AHC
OmegaMax =  1.0
Nk1 = 51   ! No. of slices for the 1st reciprocal vector
Nk2 = 51   ! No. of slices for the 2nd reciprocal vector
Nk3 = 51   ! No. of slices for the 3nd reciprocal vector
/

KCUBE_BULK
  0.00  0.00  0.00   ! Original point for 3D k plane
  1.00  0.00  0.00   ! The first vector 
  0.00  1.00  0.00   ! The second vector
  0.00  0.00  1.00   ! The third vector
```

```wt.in
&CONTROL
Boltz_OHE_calc = T ! 轨道霍尔电导
/

&PARAMETERS
EF_integral_range = 0.05  ! in eV used to define the energy range around fermi energy in calculating sigma_OHE
/

!  完成计算后, 调用/useful_scripts/post_sigma_OHE/post_sigma_OHE.py
```
![Cache_-8cb3158e7529cc.jpg](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411071720390.jpg)
S：西门子
$\Omega$ : 欧姆，$\Omega=1/S$ 

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411071949163.png)
- Gigantic intrinsic orbital Hall effects in weakly spin-orbit coupled metals
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411072259145.png)
- Universal Intrinsic Spin Hall Effect
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411080951208.png)
- Calculation of intrinsic spin Hall conductivity by Wannier interpolation
# PAOFLOW 使用
- `PAOFLOW` 读取 `WAVECAR` 和 `vasprun.xml`
- 共线体系要设 `ISYM=2`, 非共线则可以为 0 或 1
```
from PAOFLOW import PAOFLOW
paoflow = PAOFLOW(savedir='./nscf/',
                  outputdir='./output/',
                  verbose=True,
                  dft="VASP")
```



# 单位转换公式的物理背景

本公式用于将计算得到的反常霍尔电导率转换为常用的长度-厘米单位（即$1/(\Omega\cdot{\rm cm})$）。其物理来源可以从反常霍尔效应的公式出发：通常有
$$σxy=−e2ℏV∑n,kfnk Ωn,z(k) ,\sigma_{xy}=-\frac{e^2}{\hbar V}\sum_{n,\mathbf k}f_{n\mathbf k}\,\Omega_{n,z}(\mathbf k)\,,σxy​=−ℏVe2​n,k∑​fnk​Ωn,z​(k),$$

其中$e$为元电荷、$\hbar$为约化普朗克常数、$V=\omega$为晶胞体积、$\Omega_{n,z}$为Berry曲率。计算过程中常用的长度单位是原子单位（Bohr）和能量单位是电子伏特，因此需要将这些物理量转换到SI或CGS单位。下面逐项解释公式中各因子的含义和单位转换：

## Bohr长度与Å之间的转换（ANGSTROM_AU与$10^8$）​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?bohrrada0#:~:text=Image%3A%20%24a_0%24%20%20%20,11%7D%20m)

原子单位长度是玻尔半径$a_0=5.29177210544\times10^{-11},$m​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?bohrrada0#:~:text=Image%3A%20%24a_0%24%20%20%20,11%7D%20m)，即$1a_0=0.529177210544,$Å。因此$1,$Å对应$1.889727,$原子单位长度（Bohr），这就是`ANGSTROM_AU=1.889727`的含义。公式中的因子$1.0\times10^8\times\text{AU}$即相当于用厘米替代Bohr单位：一个Bohr对应$5.29177\times10^{-9},$cm，所以$1/\text{Bohr}=1.889727\times10^8,$cm$^{-1}$。换言之，$10^8$是将Å转为cm的因子（$1,$Å＝$10^{-8},$cm），与1.889727结合后实现了Bohr单位到厘米的换算。这个因子主要用于将计算中以原子单位长度表示的结果转换成以厘米为单位，从而得到以$\text{cm}^{-1}$为单位的导电率。在Berry曲率和电导率的表达式中，自然会出现长度的倒数（如体积的倒数或布里渊区积分带来的长度维度），因此引入$10^8\times\text{ANGSTROMAU}$即可将单位统一到厘米​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?bohrrada0#:~:text=Image%3A%20%24a_0%24%20%20%20,11%7D%20m)。

## 电子伏特与能量转换：出现平方的原因​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?evj#:~:text=Numerical%20value%20%60%C2%A01.602%C2%A0176%C2%A0634%20%C2%A0x%C2%A010%5E%7B,19%7D%20J)​[sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D)

电子伏特（eV）是能量单位，定义为单个电子经过1伏电势时的能量，即$1,$eV$=1.602176634\times10^{-19},$J​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?evj#:~:text=Numerical%20value%20%60%C2%A01.602%C2%A0176%C2%A0634%20%C2%A0x%C2%A010%5E%7B,19%7D%20J)。公式中的`ELECTRONVOLT_SI=1.6021892e-19`即对应这一关系。之所以出现**平方**，是因为反常霍尔电导率的Kubo公式或Berry曲率公式中往往包含能级差的平方项。例如Berry曲率计算中有$(\epsilon_m-\epsilon_n)^{-2}$，如果能量以eV为单位，则转换到SI时要乘以$(1,\text{eV in J})^2$。更直观地，在速度算符或矩阵元中常出现能量差或能量因子，涉及到eV单位时每出现一次就带来一个$E_{\rm SI}$因子，因此出现了$(\text{ELECTRONVOLTSI})^2$。Sisl教程也指出，Berry曲率的维度为Å$^2$，而电导公式里有$\frac{e^2}{\hbar}$项​[sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D)，其中$e^2$隐含一个能量单位的转换，因此在换算时要考虑到能量单位带来的$1.602\times10^{-19},$J的平方因子。简单来说，公式中涉及两个能量量纲（如两个速度矩阵元或两个能级差），用eV表征时转换为焦耳就需要$E_{\rm SI}^2$​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?evj#:~:text=Numerical%20value%20%60%C2%A01.602%C2%A0176%C2%A0634%20%C2%A0x%C2%A010%5E%7B,19%7D%20J)​[sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D)。

## 约化普朗克常数 (H_OVER_TPI)​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?hbar#:~:text=Image%3A%20%24,34%7D%20J%C2%A0s)

`H_OVER_TPI=1.054571e-34 J·s`是约化普朗克常数$\hbar=\frac{h}{2\pi}$的数值​[physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?hbar#:~:text=Image%3A%20%24,34%7D%20J%C2%A0s)。它用于将能量与时间联系起来，比如速度算符或Berry曲率公式中出现$\frac{e^2}{\hbar}$的系数。$\hbar$的单位是J·s，将$e^2$（带$e^2$的C$^2$）除以$\hbar$可以得到电导率的SI单位（西门子）的正确组合。换算过程中，我们用焦耳单位的$\hbar$来匹配上面电子伏特转换得到的能量单位，使得最终结果能量和时间等单位在一起得到导电率的单位。

## 晶胞体积 $\omega$ 的作用

公式中的$\omega$是晶胞体积，其单位通常为立方长度（如Å$^3$或原子单位的$ a_0^3$）。体积出现在分母中意味着计算得到的是单位体积内的导电率（电导率密度）。如果$\omega$以Å$^3$表示，要转为SI体积（m$^3$或cm$^3$）也需乘以相应的转换因子（$1,$Å$^3=10^{-24},$cm$^3$）。总体上，$\omega$保证了最终电导率是以体积为基准的量。例如，若以Å为单位，则$1/\omega$相当于以Å$^{-3}$计量，结合前面的$10^8$因子就能转换到以cm$^{-3}$计量。总之，$\omega$出现在分母使单位最终包含“每体积”这一维度，这配合上其他因子可得到电导率的正确单位。

## 反常霍尔电导率公式与最终单位

综上，转换因子$cgs_conv$把计算得到的Berry曲率积分结果转化为常见的电导率单位(Ω·cm)$^{-1}$。引用Sisl教程，内禀反常霍尔电导率可以写作$\sigma_{xy}=-\frac{e^2}{\hbar}\int d^dk\sum f_i\Omega_{i,xy}(k)$​[sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D)。文中指出在3D情况下，Berry曲率有Å$^2$的量纲，积分后电导率的单位为S/Å​[sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D)。由于$1,$Å$=10^{-8},$cm，要得到以S/cm（即Ω$^{-1}$cm$^{-1}$）表示，就需要额外乘以$10^8$。这正对应$cgs_conv$中的$10^8\times\text{ANGSTROMAU}$因子。最终，应用公式后得到的电导率值的单位为Ω$^{-1}$·cm$^{-1}$（或S/cm），符合通常实验和文献中反常霍尔电导率使用的单位体系。

**参考文献：** 玻尔半径的推荐值​ [physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?bohrrada0#:~:text=Image%3A%20%24a_0%24%20%20%20,11%7D%20m)；1 eV与焦耳的换算​ [physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?evj#:~:text=Numerical%20value%20%60%C2%A01.602%C2%A0176%C2%A0634%20%C2%A0x%C2%A010%5E%7B,19%7D%20J)；约化普朗克常数值​ [physics.nist.gov](https://physics.nist.gov/cgi-bin/cuu/Value?hbar#:~:text=Image%3A%20%24,34%7D%20J%C2%A0s)；以及有关反常霍尔电导率公式和Berry曲率单位的教材或文献​ [sisl.readthedocs.io](https://sisl.readthedocs.io/en/stable/tutorials/tutorial_siesta_2_ahc.html#:~:text=%3E%20%5C%5B%5Cboldsymbol%5COmega_%7Bi%2C%5Calpha%5Cbeta%7D%20%3D%202i%5Chbar,i%2C%5Calpha%5Cbeta%7D%28%5Cmathbf%20k%29.%5C%5D) 等。上述推导保证了每一步量纲的一致性，并解释了为何要出现 $E_{\rm SI}^2$（能量转换需要平方）和 $10^8\times\text{ANGSTROMAU}$（长度单位从Bohr转到cm）等因子，从而使得 $cgs_conv$ 对应的最终单位为Ω $^{-1}$ ·cm $^{-1}$，适用于反常霍尔电导率的报告。


$$
\sigma_{\mathrm{BCD}}^{\alpha \beta \gamma}\left(\tau_{r}^{1}\right)=-\tau_{r} \frac{e^{3}}{2 \hbar} \sum_{\mathbf{k}}\left(v^{\gamma} \Omega^{\alpha \beta}+v^{\beta} \Omega^{\alpha \gamma}\right) \frac{\partial f}{\partial E}/V,
$$
- **电荷 $e$ 和约化普朗克常数 $\hbar$：** 电子电荷 $e$ 的单位为库仑 (C)，根据定义 $1\text{C}=1\text{A}\cdot1\text{s}$​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E5%BA%93%E4%BB%91#:~:text=1%E5%BA%93%E4%BB%91%20%EF%BC%9D%201%E5%AE%89%E5%9F%B9%C2%B7%E7%A7%92%EF%BC%88Image%3A%20,s%7D%20%7D%EF%BC%89)，因此 $e^3$ 的单位是 $\text{C}^3$。约化普朗克常数 $\hbar$ 的单位是焦耳·秒 (J·s)​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E6%99%AE%E6%9C%97%E5%85%8B%E5%B8%B8%E6%95%B0#:~:text=Image%3A%20,34%7D%5C%20%7B%5Cmbox%7BJ%7D%7D%5Ccdot%20%7B%5Cmbox%7Bs)，出现在分母时引入了 $1/(\text{J·s})$ 的量纲。
    
- **群速度 $v$ 和贝利曲率 $\Omega$：** 题中给出群速度 $v$ 的单位为 $\text{eV}\cdot\text{length}$。将 $\text{eV}$ 换算为焦耳（$1,\text{eV}=1.602\times10^{-19},\text{J}$），则 $v$ 的单位等价于 $\text{J}\cdot\text{m}$ (焦耳·米)。贝利曲率 $\Omega$ 的单位是面积 $\text{length}^2$ (例如 $\text{m}^2$)。费米分布函数 $f$ 本身无量纲，导数 $\partial f/\partial E$ 的单位为 $\text{eV}^{-1}$（换算后即 $\text{J}^{-1}$）。
    
- **括号内各项组合的量纲：** 将上述单位相乘，得到    $$[ v^γΩ^{αβ}(∂f/∂E) ]=(J⋅m)⋅(m^2)⋅(J^{−1})=m^3 .$$ 因此，括号内的物理量组合的量纲为体积 $\text{length}^3$。
    
- **求和 $\Sigma_k$ 及体积因子：** 对动量空间求和 $\Sigma_k$ 通常对应于积分 $\int d^dk$ 并带有体积因子，即 $\Sigma_k=V/(2\pi)^d\int d^dk$，其中 $V$ 为晶胞体积 (单位 $\text{m}^3$)。在计算体电导率时，一般需要除以总体体积才得到密度形式，因此实际中会出现一个除以 $V$ 的因子（$V$ 单位为 $\text{m}^3$）。这个过程会抵消上文所得的 $\text{m}^3$ 因素，使得最后结果不再含长度量纲。
    
- **合成总量纲：** 综合以上各因子，原公式的量纲可写作
    $$\frac{e^3}{3ℏ}[括号内]∼\frac{C^3}{J⋅s}⋅m^3⋅\frac1{m^3}=\frac{C^3}{J\cdotp s}.$$
    再用 $1\text{C}=1\text{A·s}$​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E5%BA%93%E4%BB%91#:~:text=1%E5%BA%93%E4%BB%91%20%EF%BC%9D%201%E5%AE%89%E5%9F%B9%C2%B7%E7%A7%92%EF%BC%88Image%3A%20,s%7D%20%7D%EF%BC%89)和 $1\text{J}=1\text{V·C}$（或等价地 $\text{V}=\text{J}/\text{C}$​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E4%BC%8F%E7%89%B9#:~:text=%E4%B9%9F%E5%8F%AF%E5%AE%9A%E4%B9%89%E4%B8%BA%E5%8D%95%E4%BD%8D%E5%BA%93%E4%BB%91%E7%94%B5%E8%8D%B7%E7%9A%84%E8%83%BD%E9%87%8F%2C)），可化简为
    $$\frac{C^3}{J⋅s}=\frac{(A\cdotp s)3}{(V\cdotp C)⋅s}=\frac{A}{V^2} $$
    注意，导纳（西门子）$S$ 的单位是 $\text{A}/\text{V}$ ​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E8%A5%BF%E9%96%80%E5%AD%90_\(%E5%96%AE%E4%BD%8D\)#:~:text=match%20at%20L229%20%E5%8D%95%E4%BD%8D%E5%8F%AF%E8%A1%A8%E7%A4%BA%E4%B8%BA%3A%20Image%3A,V%7D)，传统的线性电导率单位为 $\text{S·m}^{-1}$ ​ [zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E9%9B%BB%E5%B0%8E%E7%8E%87#:~:text=%E7%9A%84%E5%80%92%E6%95%B0%E3%80%82%E5%9C%A8%E5%9B%BD%E9%99%85%E5%8D%95%E4%BD%8D%E5%88%B6%E4%B8%AD%E7%9A%84%E5%8D%95%E4%BD%8D%E6%98%AF%E8%A5%BF%E9%97%A8%E5%AD%90%2F%E5%85%AC%E5%B0%BA%20%28S%C2%B7m%5E%7B)，而本公式是二阶响应，得到的量纲正是 $\text{A}/\text{V}^2$，即“西门子/伏特” ($S/V$)。由此可见，公式整体的单位确实化为 $S/V$，符合题目要求​[zh.wikipedia.org](https://zh.wikipedia.org/zh-hans/%E8%A5%BF%E9%96%80%E5%AD%90_\(%E5%96%AE%E4%BD%8D\)#:~:text=match%20at%20L229%20%E5%8D%95%E4%BD%8D%E5%8F%AF%E8%A1%A8%E7%A4%BA%E4%B8%BA%3A%20Image%3A,V%7D)。
    $$
\frac{C^3}{J\cdot s} = \frac{C^2}{V\cdot s} = \frac{A^2\cdot s}{V} ]
$$