# 一、费米-狄拉克分布函数修正
参考：[【半导体基础/器件】4费米-狄拉克分布函数（概率密度函数）！ - 知乎](https://zhuanlan.zhihu.com/p/621626486)
- 能量单位转换：[常见温度对应的能量值（meV） - Ji-Huan Guan](https://www.guanjihuan.com/archives/17895)
- [电子伏特到焦耳（J）的转换](https://www.rapidtables.org/zh-CN/convert/energy/ev-to-joule.html)
-  $1eV=1.6*10^{-19}J$
```python
def intgaussian ( eig, ene, delta ):
    # 高斯函数积分近似费米-狄拉克分布（高斯修正）
    gauss = (1.-erf((eig-ene)/delta))/2.
    return gauss
```
- `eig`：本征能量数组（形状：`(n,)`）
- `ene`：能量网格点（标量）
- `delta`：展宽参数（高斯函数宽度）
- 该函数计算高斯函数的积分，用于近似*费米-狄拉克分布函数*。费米-狄拉克分布描述了在给定温度下，电子占据某一能级的概率。由于在数值计算中，直接使用费米-狄拉克分布可能计算量大，因此常用高斯函数来近似表示。
- 公式： $$\operatorname{intgaussian}(e i g, e n e, \delta)=\frac{1-\operatorname{erf}\left (\frac{e i g-e n e}{\delta}\right)}{2}$$ 其中，erf 函数表示为$$
\operatorname{erf}(x) = \frac{2}{\sqrt{\pi}} \int_{0}^{x} e^{-t^2} \, dt$$
  物理意义表示从0到x的积分区间内，函数 $e^{-t^2}$ 的累积概率。
```python
  def intmetpax(eig, ene, delta):
    # Methfessel-Paxton 修正的费米-狄拉克分布（MP修正）
    nh = 5
    coeff = np.zeros(2 * nh)
    coeff[0] = 0.
    for n in range(2, 2 * nh, 2):
        m = n // 2
        coeff[n - 1] = (-1.) ** m / (factorial(m) * (4.0 ** m) * np.sqrt(np.pi))
    
    x = (eig - ene) / delta
    return (1. - erf(x)) / 2. + hermval(x, coeff) * np.exp(-(x ** 2)) / np.sqrt(np.pi)
  ```
- **功能**：计算 Methfessel-Paxton 修正的费米-狄拉克分布。
- 最终结果为**高斯积分结果** **+** **修正项**：$$
f_{\mathrm{MP}}(E)=f_{\text {Gaussian }}(E)+\sum_{m} \frac{(-1)^{m}}{m!4^{m} \sqrt{\pi}} H_{2 m}(x) e^{-x^{2}}$$
## **综合建议**
### **(1) 首选方法：Methfessel-Paxton（MP）**
- **理由**：
    - 在零温下，MP 方法通过高阶修正，既能保持数值稳定，又能精确逼近严格零温结果。
    - 特别适合贝利曲率积分，避免因展宽过大或过小导致的误差。
- **参数设置**：
    - 展宽参数 `delta`：建议设置为能级最小间距的 1/10（如 `delta = 0.001–0.01 eV`）。
    - 展开阶数 `nh`：通常 `nh=1` 或 `nh=2` 足够，高阶修正对精度提升有限。
### **(2) 次选方法：高斯近似**
- **理由**：
    - 计算简单，适合对计算资源有限的情况。
    - 若体系能级分布较稀疏（无密集简并态），高斯近似足够精确。
- **参数设置**：
    - `delta` 需通过收敛性测试，确保结果对参数不敏感。
# 二、计算  $\langle u_n | \nabla_k| u_n \rangle$ 即 $\psi_n^\dagger ⋅rot_{op1} ⋅\psi_n$ 和 $\psi_n^\dagger ⋅rot_{op2} ⋅\psi_n$
## 初始化矩阵
```python
jksp = np.zeros((dks[0],dks[2],dks[3],dks[4]), order="C", dtype=complex)
pksp = np.zeros_like(jksp)
```
**数学意义** ：  
初始化两个复数矩阵 `jksp` 和 `pksp`，形状为 ($N_k$ ​, $N_{band}​$, $N_{band}​$, $N_{spin}$ ​)，分别存储**电流矩阵元** 和**动量矩阵元**
## `Perturb_split` 处理简并和非简并情况
`def perturb_split(rot_op1,rot_op2,v_k,degen,return_v_k=False):`
### 非简并
```python
`def perturb_split(rot_op1, rot_op2, v_k, degen, return_v_k=False):`
    op1 = np.dot(np.conj(v_k.T),np.dot(rot_op1,v_k)) 
    if len(degen)==0: 
        op2 = np.dot(np.conj(v_k.T),np.dot(rot_op2,v_k))
```
计算  $op1=V_k^\dagger ⋅rot_{op 1} ⋅V_k$，$op2=V_k^\dagger ⋅rot_{op 2} ⋅V_k$
- $rot_{op 1}$ ：旋转算符
- $V_k$：基态波函数，可等同于 $\psi_n$
### 简并
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202503192327406.png)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202503192329587.png)
# 三、Berry 曲率计算

```
    """
    计算Berry曲率
    
    参数:
        jksp: 电流矩阵元
        pksp: 动量矩阵元
    返回:
        ene: 能量网格
        shc: 自旋霍尔电导
        Om_zk: z方向的Berry曲率
    """
```
## 参数提取
```python
    arrays, attributes = DataController.data_dicts()
    snktot, nawf, _, nspin = pksp.shape  # snktot: k 点总数，nawf: 原子轨道数
    fermi_up, fermi_dw = attributes['fermi_up'], attributes['fermi_dw']  # 上下自旋费米能级
    nk1, nk2, nk3 = attributes['nk1'], attributes['nk2'], attributes['nk3']  # k 点网格维度
```
## 初始化 Berry 曲率数组
```python
    Om_znkaux = np.zeros((snktot, nawf), dtype=float)  # 存储每个 k 点和轨道的 Berry 曲率
    deltap = 0.05  # 能量差展宽参数，避免除以零
```
## ⭐计算每个 k 点的 Berry 曲率
$$\Omega_{i j}^{n}(k)=-2 \sum_{m \neq n} \frac{\operatorname{Im}\left(p_{m n}^{i}(k) p_{n m}^{j}(k)\right)}{\left(E_{m}(k)-E_{n}(k)\right)^{2}+\delta_{p}^{2}}$$
```python
    for ik in range(snktot):
        # 计算能量差的平方 + deltap^2，避免分母为零
        E_nm = (arrays['E_k'][ik, :, 0] - arrays['E_k'][ik, :, 0][:, None]) ** 2 + deltap ** 2
        E_nm[np.where(E_nm < 1.e-4)] = np.inf  # 将过小的能量差设为无穷大，避免数值不稳定
        # 计算 Berry 曲率贡献：虚部求和
        Om_znkaux[ik] = -2.0 * np.sum(np.imag(jksp[ik, :, :, 0] * pksp[ik, :, :, 0].T) / E_nm, axis=1)
    E_nm = None  # 释放内存
```
设置能量网络
```python
    attributes['emaxH'] = np.amin(np.array([attributes['shift'], attributes['emaxH']))  # 能量范围上限
    esize = 500  # 能量网格点数
    ene = np.linspace(attributes['eminH'], attributes['emaxH'], esize)  # 生成能量网格
```
计算能量积分
```python
    Om_zkaux = np.zeros((snktot, esize), dtype=float)  # 存储每个 k 点和能量点的积分结果
    for i in range(esize):
        if attributes['smearing'] == 'gauss':
            # 高斯展宽积分
            Om_zkaux[:, i] = np.sum(Om_znkaux[:, :] * intgaussian(arrays['E_k'][:, :, 0], ene[i], arrays['deltakp'][:, :, 0]), axis=1)
        elif attributes['smearing'] == 'm-p':
            # Methfessel-Paxton 修正积分
            Om_zkaux[:, i] = np.sum(Om_znkaux[:, :] * intmetpax(arrays['E_k'][:, :, 0], ene[i], arrays['deltakp'][:, :, 0]), axis=1)
        else:
            # 无展宽（阶梯函数）
            Om_zkaux[:, i] = np.sum(Om_znkaux[:, :] * (0.5 * (-np.sign(arrays['E_k'][:, :, 0] - ene[i]) + 1)), axis=1)
```
在费米能级处提取 Berry 曲率
```python
    n0, n = 0, esize - 1  # 初始化费米能级索引
    for i in range(esize - 1):
        if ene[i] <= fermi_dw and ene[i + 1] >= fermi_dw:
            n0 = i  # 下自旋费米能级索引
        if ene[i] <= fermi_up and ene[i + 1] >= fermi_up:
            n = i  # 上自旋费米能级索引
    # 重塑数组并计算差值
    Om_zk = np.reshape(Om_zkaux, (nk1, nk2, nk3, esize), order='C')
    Om_zk = Om_zk[:, :, :, n] - Om_zk[:, :, :, n0]  # 提取费米面处的 Berry 曲率
```



$$\Omega^{n}(\mathbf{R})  =\nabla_{\mathbf{R}} \times \mathbf{A}_{\mathbf{n}}(\mathbf{R})$$ 
$$\Omega_{\mu \nu}^{n}(\mathbf{R}) =\partial_{\mu}\left (\mathbf{A}_{\mathbf{n}}\right)_{\nu}-\partial_{\nu}\left (\mathbf{A}_{\mathbf{n}}\right)_{\mu}=i\left (\left\langle\left.\frac{\partial}{\partial_{\mathbf{R}_{\mu}}} u_{n}(\mathbf{R}) \right\rvert\, \frac{\partial}{\partial_{\mathbf{R}_{v}}} u_{n}(\mathbf{R})\right\rangle-\left\langle\frac{\partial}{\partial_{\mathbf{R}_{v}}} u_{n}(\mathbf{R}) \left\lvert\, \frac{\partial}{\partial_{\mathbf{R}_{\mu}}} u_{n}(\mathbf{R})\right.\right\rangle\right)=-2 I m\left (\left\langle\left.\frac{\partial}{\partial_{\mathbf{R}_{\mu}}} u_{n}(\mathbf{R}) \right\rvert\, \frac{\partial}{\partial_{\mathbf{R}_{\nu}}} u_{n}(\mathbf{R})\right\rangle\right)$$
$$\Omega^{n}(\mathbf{R}) =-I m \sum_{m \neq n} \frac{\left\langle u_{n}(\mathbf{R})\right| \nabla_{R} H (\mathbf{R})\left|u_{m}(\mathbf{R})\right\rangle \times\left\langle u_{m}(\mathbf{R})\right| \nabla_{R} H (\mathbf{R})\left|u_{n}(\mathbf{R})\right\rangle}{\left (E_{n}-E_{m}\right)^{2}} $$
$$\Omega_{\mu \nu}^{n}(\mathbf{R}) =i \sum_{m \neq n} \frac{\left\langle u_{n}\right| \frac{\partial H}{\partial_{\mathbf{R}_{\mu}}}\left|u_{m}\right\rangle\left\langle u_{m}\right| \frac{\partial H}{\partial_{\mathbf{R}_{p}}}\left|u_{n}\right\rangle-\left\langle u_{n}\right| \frac{\partial H}{\partial_{\mathbf{R}_{\nu}}}\left|u_{m}\right\rangle\left\langle u_{m}\right| \frac{\partial H}{\partial_{\mathbf{R}_{p}}}\left|u_{n}\right\rangle}{\left (E_{n}-E_{m}\right)^{2}}$$

单位换算问题：[DFT入门经验帖 - 知乎](https://zhuanlan.zhihu.com/p/590975571)



$$\sigma_{SH} = \frac{1}{N_k} \sum_{k} \Omega(k,\epsilon_F)$$$$
\Omega_z^n(k) = -2\sum_{m}\frac{{\rm Im}[j_{nm}(k)p_{mn}(k)]}{(E_n(k)-E_m(k))^2+\delta^2}
$$
$$
\Omega_z(k,\epsilon) = \sum_n \Omega_z^n(k) \cdot f_n(k,\epsilon)
$$
$$
\sigma_{xy} = \frac{e^2}{\hbar} \cdot \frac{1}{V_{\rm BZ}} \sum_k \Omega_z(k)
$$
$$
\sigma_{xy} = \sigma_{xy}(E_F+\Delta E) - \sigma_{xy}(E_F-\Delta E)
$$
$$
\Theta(E - \epsilon_i) = \frac{1}{2}(-\text{sign}(E - \epsilon_i) + 1)
$$
$$
\Omega(E) = \sum_n \Omega_n \cdot \frac{1}{\sqrt{2\pi}\sigma} \exp\left(-\frac{(E_n - E)^2}{2\sigma^2}\right)
$$
$$
\Omega_k(E_i) = \sum_n \Omega_n(k) \cdot w_{n}^{MP}(E_i)
$$

$$
\frac{\partial H_{nm}^\sigma(\mathbf{R})}{\partial k_l} = i \cdot a_0 \cdot A \cdot R_l \cdot H_{nm}^\sigma(\mathbf{R})
$$


$F (E) = \frac{1}{1+e^{\frac{E}{k_B T}} }$ 可以替换成高斯近似 
其中 $\operatorname{erf}(x) = \frac{2}{\sqrt{\pi}} \int_{0}^{x} e^{-t^2} \, dt$

一阶导：$\frac{e^{\frac{E}{k_B T}}}{(1+e^{\frac{E}{k_B T}_) 2}}=$
