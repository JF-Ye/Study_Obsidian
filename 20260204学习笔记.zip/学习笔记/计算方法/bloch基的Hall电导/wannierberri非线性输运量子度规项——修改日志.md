# `formula/coveriant.py` 添加类 `MetricTensor` 计算量子度规
公式：
$$\left\{\begin{array}{l}
G_{n}^{a b}=\operatorname{Re} \sum_{m \neq n} \frac{\langle n| \partial_{a} \mathcal{H}|m\rangle\langle m| \partial_{b} \mathcal{H}|n\rangle}{\left (\varepsilon_{n}-\varepsilon_{m}\right)^{2}}, \\
\Omega_{n}^{a b}=-2 \operatorname{Im} \sum_{m \neq n} \frac{\langle n| \partial_{a} \mathcal{H}|m\rangle\langle m| \partial_{b} \mathcal{H}|n\rangle}{\left (\varepsilon_{n}-\varepsilon_{m}\right)^{2}},
\end{array}\right.$$
1. 更改 `formula/covariant.py   class MetricTensor
2. 添加 `factors.py    factor_quantum_metric `
```corvariant.py
class MetricTensor

class VelMetric(FormulaProduct):
    def __init__(self, data_K, **kwargs_formula):
        super().__init__([data_K.covariant('Ham', commader=1), MetricTensor(data_K, **kwargs_formula)], name='VelMetric')
```



可以只考虑内部项，不考虑外部项。我研究的内部项的物理。
删除外部项 external_terms
[Methods — Wannier Berri 1.3.0 documentation](https://docs.wannier-berri.org/en/master/methods.html)


测试没有 external_term 项的 berrycurvtrue

$\lvert u(\mathbf{k}\rangle$
$\alpha(\mathbf{k})=\chi[\cos(k_x a)+\cos(k_y a)]$
$m^b = \frac{1}{2}\epsilon_{bcd} r^c v^d$
$\frac{1}{2} Re\langle m|m^b|n\rangle$
$$
\Omega_n^{αβ} \ += \ \frac{1}{2} \mathcal{O}_n^{αβ}
$$
$$
Ω_n^{αβ} = \text{Im}\left[ \langle ∂^α u_n | ∂^β u_n \rangle \right] + \frac{1}{2}\mathcal{O}_n^{αβ} + \cdots
$$
$$\mathcal{O}_n^{αβ} = \text{Re}\langle \partial_α u_n | H | \partial_β u_n \rangle$$

$$$\Omega_{mn,c} = -i \sum_{a,b} \epsilon_{abc} \langle u_{mk} | \partial_a u_{lk} \rangle \langle u_{lk} | \partial_b u_{nk} \rangle$$ $\frac{1}{2} \langle u_{mk}| \hat{O}_c | u_{nk} \rangle$
$\hat{O}_c = \epsilon_{abc} \partial_a A_b$
