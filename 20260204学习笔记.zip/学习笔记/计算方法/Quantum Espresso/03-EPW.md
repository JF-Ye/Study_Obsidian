# 概览
- 官网：[EPW Software (epw-code.org)](https://epw-code.org/)
- 官网 school 有很多具体例子：[Summer School 2024 — EPW documentation](https://docs.epw-code.org/doc/School2024.html)
- 教程：[QUANTUM ESPRESSO：EPW - 谢华的博客 | Xiehua's Blog (xh125.github.io)](https://xh125.github.io/2021/12/16/QE-epw/)
- 教程 2：[qe-study](https://github.com/nawu97/qe-study/blob/main/Wed.4.Verdi.pdf)
- 官网参数说明：[点击这里](https://docs.epw-code.org/doc/Inputs.html#inputepw)
- 能做什么？
> 1. 超导特性
> 2. 不同温度下的能带结构
> 3. 输运性质和热载流子动力学

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202407192041003.png)
# 一、SCF 自洽计算
# 二、`ph.x` 声子谱计算
# 三、`pp.py` 提取 `.dvscf` 和 `.dyn` 文件到save文件夹
# 四、创建 epw 新目录进行 SCF 计算
- 调用 `kmesh.pl` 脚本生成 K 点 (用计算声子的网格)
```
./kmesh.pl 3 3 3 &> kpoint
```
- 将 `kpoint` 文件里的 K 点复制进 `pwscf.in` 进行自洽计算
```
K_POINTS {crystal}
216
  0.00000000  0.00000000  0.00000000  4.629630e-03
.......
```
# 五、进行 nscf 计算
# 六、进行 EPW 计算
- 核心：计算布里渊区每个不可约 q 点的（k, k+q）点的*电-声耦合矩阵*，并利用对称性展开到整个布里渊区
## 控制参数
### amass：原子质量
- 不设则从文件中读取
### ep_coupling：运行电声耦合计算
- Default：.true.
### elph：计算电声耦合系数
- Default：. False.
### epbwrite：输出电声矩阵和 dyn 矩阵的 `.epb`  文件
- Default：.false.
### epbread：读取 `.epb` 文件
- Default：.false.
### epwwrite：输出电声矩阵和 dyn 矩阵的文件
- Default：.true.
### epwread：从 `epwdata.fmt` 和 `XX.epmatwpX` 中读取电声矩阵
- Default：.false.
- 用于重启计算，同时还要设 `kmaps=.true.` 
### ephwrite：输出 `.ephmat`, `.freq`, `.egnv`, `.ikmap` 文件
### etf_mem：控制内存参数
- Default：1
- **`etf_mem=1`**：电声矩阵存储于内存中，计算更快
- **`etf_mem=2`**：更少内存
### iverbosity：超导参数调控
- 0：default，短输出
- 1：详细输出
- 2：超导部分详细输出
- 3：仅针对电声部分详细输出
## Wannier 90 参数
### nbndsub：需要 wannier 函数的数量
- Default：0
- 等价于 `num_wann`
### wannierize：计算 wannier 函数
- Default：.false.
- 输出 wannier 矩阵文件 `.filukk
### num_iter：参考 wannier 90 计算
### dis_froz_min 和 dis_froz_max：参考 wannier90 计算
- 跟 wannier 90 一样的设置参数方法，不过要注意费米能级
### wannier plot
- 设为 `.true.`，则输出实空间 Wannier 函数
### proj (i)
## 计算标准参数
### eps_acustic
### fsthick：费米表面窗口宽度
- Default：1.d10 
- 单位：eV
- 只有在费米能级的几个声子能量范围内的电子状态才会对声子线宽有贡献
- 推荐设置：`fsthick = 4 × 最大声子频率`，最大声子频率看声子谱最大值，转换为 eV 单位。后面几个参数同理
### wscut：Eliashberg 方程的频率积分上限
- Default：1.d0
- 单位：eV
- 推荐设置：`wscut = 10 × 最大声子频率`
### muc：库伦相互作用参数
- 推荐设置：0.1~0.2
### degaussw：能量函数的展宽
- Default：0.025
- 单位：eV
- 推荐设置：`degaussw = 1/4 × fsthick`
### degaussq：电声耦合的展宽
- Default：0.05
- 一般取 0.05~0.2 meV
### nsmear
### delta_smear
### nqstep
### eliashberg：求解 Elashberg 方程
- Default：`.false.`
- `.true.`，求解 Elashberg 方程
### laniso：求解各向异性 Elashberg 方程
- 需要读取 `.ephmat`, `.freq`, `.egnv`, `.ikmap` 文件，以上文件可通过 `ephwrite=.true` 获得
### liso：求解各向同性 Elashberg 方程
- 需要读取 `.ephmat`, `.freq`, `.egnv`, `.ikmap` 文件或者 Eliashberg 谱函数
### limag：求解 Eliashberg 方程的虚部
### lpade：将 Eliashberg 方程的虚部延续到实部
### conv_thr_iaxis
### nstemp
### temps：Eliashberg 方程中求解的温度
### nsiter
### dvscf_dir
### nk1：粗网格
### nq1
### mp_mesh_k
### nkf1：精细网格
- 由于要对声子带宽（phono linewidths）和电声耦合强度（e-ph coupling strength）进行关于 $k$ 的积分计算，所以要更密的网格
### nqf1

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412271633024.png)

# 七、计算 Tc
### 1 . 更改如下参数，确定线性 ME 方程下的超导温度
- wannier 部分全部注释或删去
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202410290915690.png)
### 2 . 在原先的 `epw.in` 文件中，在上面计算出来的 Tc 范围内，设置多个 temps
```
ep_coupling = .false.
elph        = .false.

epbwrite    = .false.
epbread     = .false.

epwwrite = .false.
epwread  = .true.

wannierize  = .false.

ephwrite    = .false.

lpade = .false.
lacon = .false.

fila2f = 'capd5.a2f'
tc_linear = .true.
tc_linear_solver = 'power'

nstemp   = 21     ! Nr. of temps
temps    = 0.25 5.25

```
### 3 . 计算超导带隙趋于 0
```
ep_coupling = .false.
elph        = .false.
epwwrite = .false.
epwread  = .true.  
wannierize  = .false.
ephwrite= .false.
eliashberg  = .true.
liso = .true.
limag = .true.
lpade = .false.

! tc_linear=.true.  ！注释这个
fila2f= 'capd5.a2f'

nstemp   = 1     ! Nr. of temps
temps    = 0.25 1.25 2.25 3.25 3.75 4.00 4.25 4.5
```
- 运行脚本，从 `perfix.imag_iso_*` 中提取第二行，第四列为超导带隙
```
#!/bin/bash 

# 提示用户输入前缀
read -p "请输入文件前缀 (prefix): " prefix

# 处理文件
awk -v pfx="$prefix" 'FNR==2{print FILENAME,$0}' "${prefix}.imag_iso_"* | awk '{print $1 "  " $4*1000}' > "${prefix}.imag_iso_gap_tot"
sed -i "s/${prefix}.imag_iso_//" "${prefix}.imag_iso_gap_tot"
```
生成 `capd5.imag_iso_gap_tot`
# 八、计算声子线宽
```
ep_coupling = .true.		!!!!
elph        = .true.		!!!!
epbwrite = .false.
epbread  = .false.
epwwrite = .false.
epwread  = .true.		

wannierize  = .false.

ephwrite = .false.
eliashberg = .false.	!!!!

nstemp = 1
temps    = 0.075	!!!

mp_mesh_k = .false.
！ 删除nqf1, nqf2, nqf3

!!!!!!----添加参数-------
phonselfen = .true.
delta_approx = .true.

filqf = './path.dat'     ! 用kpath_generate.py 脚本生成path.dat
```
## 将计算 `path.dat` 文件里的所有点, `kpath_generate.py` 脚本如下
- 其中，`num_points=200` 要跟 `matph.in` 文件里的 K 点数匹配，否则我 matlab 后处理时会有问题
```kpath_generate.py
#! /THL7/software/python/3.8_anaconda_2020.07/bin/python
# 2024/12/9 Jiefeng Ye
# 生成kpath，及其权重
# 需要更改path变量中的路径
#
from __future__ import print_function
import numpy as np

# 定义每一段的起点和终点
paths = [
    ([0.0, 0.0, 0.0], [0.5, 0.0, 0.0]),       # Γ -> M
    ([0.5, 0.0, 0.0], [1/3, 1/3, 0.0]),      # M -> K
    ([1/3, 1/3, 0.0], [0.0, 0.0, 0.0]),      # K -> Γ
    ([0.0, 0.0, 0.0], [0.0, 0.0, 0.5])      # Γ -> A
]

# 每段路径的分割点数
num_points = 200

# 计算总点数
total_points = len(paths) * num_points + 1  # 每段生成 num_points，最后一个终点单独计入
weight = 1.0 / total_points  # 每个点的权重

# 打开文件写入数据
with open("path.dat", "w") as file:
    file.write(f"{total_points} crystal\n")
    for start, end in paths:
        # 生成从起点到终点的线性插值
        segment = np.linspace(start, end, num_points, endpoint=False)
        for k in segment:
            # 格式化并写入文件（包括权重）
            file.write("{:.6f} {:.6f} {:.6f} 1.0\n".format(k[0], k[1], k[2]))
    # 将最后一个点写入文件
    file.write("{:.6f} {:.6f} {:.6f} 1.0\n".format(*paths[-1][1]))

print(f"Path data written to path.dat with {total_points} k-points and weight {weight:.6f}.")

```
## 输出文件分析
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412171654577.png)
- 抬头为 `path.dat` 里的第一个点的坐标
- lambda 为声电耦合强度
- Gamma 为声子线宽，输出的 `linewidth.phself.**K` 是将该列数值乘 2（不清楚为何）
- Omega 为声子频率，即声子谱
- 数据都是用 `lambda___`，不用 `lambda_tr`
# 八、计算经验
## 1. 第一次计算时，记得将 temps 设比较低的值，确认有没有超导带隙，再去算 Tc
-  `temps` 也非常影响 Eliashberg 方程的收敛
## 2. `muc` 参数设置 - 库伦作用项
- 设置成 `0.1 0.2` 更容易收敛，更多人用 `0.1`
- 并非 `muc` 越大超导带隙/超导转变温度越高
- 不影响声电耦合强度
## 3. 各向同性和各向异性参数不影响声电耦合强度
## 4. `temps` 温度参数不影响声电耦合强度
## 5. 计算以下步骤时若断了，重新提交任务可以直接续算
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412310910892.png)

# 九、范例
```
--
&inputepw
  prefix      = 'MgB2',
  amass(1)    = 24.305,
  amass(2)    = 10.811
  outdir      = './'

  ep_coupling = .true.
  elph        = .true.
  epbwrite    = .true.
  epbread     = .false.

  epwwrite = .true.
  epwread  = .false.

  etf_mem     =  1 

  nbndsub     =  5,

  wannierize  = .true.
  num_iter    = 500
  dis_froz_max= 8.8
  proj(1)     = 'B:pz'
  proj(2)     = 'f=0.5,1.0,0.5:s'
  proj(3)     = 'f=0.0,0.5,0.5:s'
  proj(4)     = 'f=0.5,0.5,0.5:s'

  iverbosity  = 2

  eps_acustic = 2.0    
  ephwrite    = .true. 

  fsthick     = 0.4  ! eV
  degaussw    = 0.10 ! eV
  nsmear      = 1
  delta_smear = 0.04 ! eV

  degaussq     = 0.5 ! meV
  nqstep       = 500
  
  eliashberg  = .true.

  laniso = .true.
  limag = .true.
  lpade = .true.

  conv_thr_iaxis = 1.0d-4

  wscut = 1.0   ! eV  

  nstemp   = 1     ! Nr. of temps
  temps    = 15.00 

  nsiter   = 500

  muc     = 0.16

  dvscf_dir   = '../phonons/save'
  
  nk1         = 6
  nk2         = 6
  nk3         = 6

  nq1         = 6
  nq2         = 6
  nq3         = 6

  mp_mesh_k = .true.
  nkf1 = 20
  nkf2 = 20
  nkf3 = 20

  nqf1 = 20
  nqf2 = 20
  nqf3 = 20
```