链接：[WannierBerri advanced tutorial - Fermi surface and Fermi sea calculation of the Berry curvature dipole — Wannier Berri 1.2.1 documentation](https://tutorial.wannier-berri.org/tutorials/2_fermi_sea_vs_fermi_surface/solution/tutorial_sea_vs_surface_solution.html)
# 1. 手性紧束缚模型
```
import os
import numpy as np
import scipy
import matplotlib.pyplot as plt
import wannierberri as wberri
from wannierberri import calculators as calc






import wannierberri.models

# --------------调用pythtb包，构建紧束缚模型--------------------------

# Initiate a tight-binding model (wannierberri.models.Chiral uses PythTB)
model_Chiral_left = wannierberri.models.Chiral(delta=2., hop1=1., hop2=0.3, phi=0, hopz_left=0.2, hopz_right=0.0, hopz_vert=0)

# Initialize WannierBerri system object
system = wberri.System_PythTB(model_Chiral_left)

print("=" * 40)

# Set symmetry from the generators.
system.set_pointgroup(symmetry_gen=["TimeReversal", "C3z"])
print("Number of symmetry operations: ", system.pointgroup.size)


path = wberri.Path(
    system,
    nodes=[
        [2/3, 1/3, 0.],  #  K
        [0.,  0.,  0.],  #  Gamma
        [1/2, 0.,  0.],  #  M
        [2/3, 1/3, 0.],  #  K
        [2/3, 1/3, 0.5],  #  H
        [0.,  0.,  0.5],  #  A
        [1/2, 0.,  0.5],  #  L
        [2/3, 1/3, 0.5],  #  H
    ],
    labels=["K","$\Gamma$","M","K", "H", "A", "L", "H"],
    length=50
)

calculators = {
    "tabulate": calc.TabulatorAll(
        {"Energy": calc.tabulate.Energy()},
        ibands=np.arange(system.num_wann),
        mode="path",
    )
}

path_result = wberri.run(
    system,
    grid=path,
    calculators=calculators,
    print_Kpoints = False,
)

path_result = path_result.results["tabulate"]

# 画价带顶、导带底，但需要知道第几条带。自己计算可以不画-----------------
e_vbm = np.amax(path_result.get_data("Energy", 0))
e_cbm = np.amin(path_result.get_data("Energy", 1))
print(f"Valence band maximum   : {e_vbm:6.3f}")
print(f"Conduction band minimum: {e_cbm:6.3f}")
print("VBM k point: ", path_result.kpoints[np.argmax(path_result.get_data("Energy", 0))])
print("CBM k point: ", path_result.kpoints[np.argmin(path_result.get_data("Energy", 1))])
# ------------------------------------------------------------------

fig = path_result.plot_path_fat(path, close_fig=False, show_fig=False)

ax = fig.get_axes()[0]
ax.axhline(e_vbm, c="k", ls="--")
ax.axhline(e_cbm, c="k", ls="--")
plt.show(fig)

```
```
# -------------开始计算BCD------------------------------------------------

from wannierberri.smoother import FermiDiracSmoother

# ----------设置BCD计算的能量范围：[-2,1] 撒点101 -------------------------
efermi = np.linspace(-2.0, 1.0, 101, True)
# efermi = np.linspace(e_vbm - 0.5, e_cbm + 0.5, 301, True)

kwargs = dict(
    Efermi=efermi,
    kwargs_formula={"external_terms": False},
    smoother=FermiDiracSmoother(efermi, T_Kelvin=1200, maxdE=8)
)

calculators = {
    'berry_dipole_fermi_sea': calc.static.BerryDipole_FermiSea(**kwargs),
    'berry_dipole_fermi_surface': calc.static.BerryDipole_FermiSurf(**kwargs),
    'dos': calc.static.DOS(Efermi=efermi,),
}


grid = wberri.Grid(system, NK=20, NKFFT=2)
result = wberri.run(
    system,
    grid=grid,
    calculators=calculators,
    parallel=parallel,
    print_Kpoints = False,
    use_irred_kpt = True,	# 默认，用不可约表示提升计算速度
)

data_fsurf = result.results['berry_dipole_fermi_surface'].data
data_fsea = result.results['berry_dipole_fermi_sea'].data

print("Shape of data: ", data_fsurf.shape)

print("Maximum value for each components (Fermi surface): ")
print(np.linalg.norm(data_fsurf, axis=0))

print("Maximum value for each components (Fermi sea): ")
print(np.linalg.norm(data_fsea, axis=0))


# ------绘图，分别是沿xx, yy, zz方向的BCD------------------------------------
dir_string = ["D_xx", "D_yy", "D_zz"]
for i in range(3):
    plt.plot(efermi, data_fsurf[:, i, i], c=f"C{i}", label="Fermi surface " + dir_string[i])
    plt.plot(efermi, data_fsea[:, i, i], c=f"C{i}", label="Fermi sea " + dir_string[i], ls="--")

# plt.plot(efermi, result.results['dos'].data, "k-")

plt.axhline(0, c="k", lw=1)
plt.xlabel("Fermi level")
plt.ylabel("Berry curvature dipole")
plt.axvline(e_vbm, c="k", lw=1, ls="--")
plt.axvline(e_cbm, c="k", lw=1, ls="--")
plt.legend()
plt.show()
```

# 2. Wannier90 计算案例
```python
import wannierberri as wberri
print (f"Using WannierBerri version {wberri.__version__}")
import numpy as np
import scipy
import matplotlib.pyplot as plt
from termcolor import cprint
from wannierberri import calculators as calc
from wannierberri.smoother import FermiDiracSmoother

# 需要文件：wannier90_tb.dat
system=wberri.System_tb('wannier90_tb.dat',berry=True)

# ----修改原子信息------------------------------------------------------
system.symmetrize(
    proj=["Ge:s", "Ge:p", "Te:s", "Te:p"],
    atom_name=["Ge", "Te"],
    positions=[[0., 0., 0.], [0.4688262167, 0.4688262167, 0.4688262167]],
    # magmom = [[0,0,1],[0,1,0]] # 跟INCAR设置一样，笛卡尔坐标
    soc=True,
)

path = wberri.Path(
    system,
    nodes=[
        [0.00000, 0.00000, 0.00000], # GAMMA
        [0.50000, 0.00000, 0.00000], # L
        [0.62910, 0.62910, 0.24180], # U
        [0.50000, 0.50000, 0.00000], # X
        [0.00000, 0.00000, 0.00000], # GAMMA
        [0.50000, 0.50000, 0.50000], # Z
        [0.62910, 0.62910, 0.24180], # U
    ],
    labels=["$\Gamma$","L","U","X", "$\Gamma$", "Z", "U"],
    length=50
)
# ------------------------------------------------------------------

# -----------------定义calculator------------------------------
calculators = {
    "tabulate": calc.TabulatorAll(
        {"Energy": calc.tabulate.Energy()},
        ibands=np.arange(system.num_wann),
        mode="path",
    )
}
# -------------------------------------------------------------

# 计算能带
path_result = wberri.run(
    system,
    grid=path,
    calculators=calculators,
    print_Kpoints = False,
)
path_result = path_result.results["tabulate"]

# 保存计算能带文件------------------
def kpath_distance(k_points):
    # 计算相邻点之间的欧几里得距离
    distances = np.linalg.norm(np.diff(k_points, axis=0), axis=1)
    # 累积距离，开头补0
    x_axis = np.concatenate([[0], np.cumsum(distances)])
    return x_axis

energy = path_result.results['Energy'].data
# print(path.labels)
x_axis = kpath_distance(path.K_list)
output = np.column_stack((x_axis, energy))
np.savetxt("berri_band.dat", output, fmt="%.8f", delimiter="\t",comments="")

# 绘图---------------------
fig = path_result.plot_path_fat(path, close_fig=False, show_fig=False) 
ax = fig.get_axes()[0]
plt.show(fig)
#plt.savefig("Band.png", dpi=300, bbox_inches="tight")
#plt.close(fig)

```
```python

# -----------------计算BCD--------------------------------------
# 设置横坐标能量区间
# 费米能级5.0156，设未减去费米能级的能量范围
efermi = np.linspace(3.5, 5.5, 301, True)   

smoother = FermiDiracSmoother(efermi, 300.0)

kwargs = dict(
    Efermi=efermi,
    smoother=smoother,
)

calculators = {
    'berry_dipole_fermi_sea': calc.static.BerryDipole_FermiSea(**kwargs),
    'berry_dipole_fermi_surface': calc.static.BerryDipole_FermiSurf(**kwargs),
}

# ------------NK是关键数值，需要测试收敛，此处选fermi_surface方法测试---------------
data_GeTe_fsurf_all = {}
data_GeTe_fsea_all = {}

for nk in [60, 80, 120, 160, 200]:
    grid = wberri.Grid(system, NK=nk)
    result = wberri.run(
        system,
        grid=grid,
        calculators=calculators,
        #parallel=parallel,
        print_Kpoints = False,
    )
    data_GeTe_fsurf_all[nk] = result.results['berry_dipole_fermi_surface'].dataSmooth
    data_GeTe_fsea_all[nk] = result.results['berry_dipole_fermi_sea'].dataSmooth
    
# 保存数据
np.savez("data_GeTe_fsurf_all.npz", **{str(k): v for k, v in data_GeTe_fsurf_all.items()})
np.savez("data_GeTe_fsea_all.npz", **{str(k): v for k, v in data_GeTe_fsea_all.items()})
# 读取方法
# data_GeTe_fsurf_all={}
# data_GeTe_fsea_all={}
# data_GeTe_fsurf_all = np.load("data_GeTe_fsurf_all.npz")
# data_GeTe_fsea_all = np.load("data_GeTe_fsea_all.npz")


# 绘图
ic = 0
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
for nk in sorted(list(data_GeTe_fsurf_all.keys())):
    c = f"C{ic}"
    axes[0].plot(efermi, data_GeTe_fsurf_all[nk][:, 0, 1], c=c, label=f"NK={nk}")      # [:,0,1]对应张量D_xy=∂x Ωy
    axes[1].plot(efermi, data_GeTe_fsea_all[nk][:, 0, 1], c=c, label=f"NK={nk}")
    ic += 1

axes[0].set_title("Fermi surface")
axes[1].set_title("Fermi sea")

for ax in axes:
    ax.axhline(0, c="k", lw=1)
    ax.set_ylim([-0.05, 0.05])
    ax.set_xlabel("Fermi level (eV)")
    ax.set_ylabel("Berry curvature dipole")

axes[1].legend()
plt.tight_layout()

plt.show()
#plt.savefig("berry_curvature_dipole.png", dpi=300, bbox_inches="tight")
#plt.close(fig)

```
```python
# ------------上一步确定了NK数值后，开始静态计算BCD_xyz方向投影和电导率σ------------------
# 只需要前面一个参数 efermi
efermi = np.linspace(3.5, 5.5, 301, True)
# 更改温度
smoother = FermiDiracSmoother(efermi, T_Kelvin=1.0)
# 不变
kwargs = dict(
    Efermi=efermi,
    smoother=smoother,
)

# 输入刚刚确定的网格NK
grid = wberri.Grid(system, NK=120)
# 定义calculator，注意这里用的是静态static方法定义
dim_calculators = {
    # 计算BCD
    'berry_dipole_fermi_sea': calc.static.BerryDipole_FermiSea(**kwargs),    
    'berry_dipole_fermi_surface': calc.static.BerryDipole_FermiSurf(**kwargs),
    # 计算电导σ
    'sigma_fermi_sea': calc.static.NLAHC_FermiSea(**kwargs),
    '_fermi_surface': calc.static.NLAHC_FermiSurf(**kwargs),
    'dos': calc.static.DOS(Efermi=efermi,),
}


# 运算
result = wberri.run(
    system,
    grid=grid,
    calculators=dim_calculators,
    print_Kpoints = False,
)

# ------保存和提取数据----
# result.results是个字典，键为dim_calculators中定义的键
# 保存每个键对应的.data数据
for key in result.results.keys():		
    data = result.results[key].data
    np.save(f'data_{key}.npy', data)
    print(f'已保存 {key}.npy，数据形状为：{data.shape}')


# 绘图
# dir_string = ["D_xx", "D_yy", "D_zz"]
# for i in range(3):
#     plt.plot(efermi, data_fsurf[:, i, i], c=f"C{i}", label="Fermi surface " + dir_string[i])
#     plt.plot(efermi, data_fsea[:, i, i], c=f"C{i}", label="Fermi sea " + dir_string[i], ls="--")

# plt.axhline(0, c="k", lw=1)
# plt.xlabel("Fermi level")
# plt.ylabel("Berry curvature dipole")

# plt.legend()
# plt.show()


# -----------------计算frmst文件，得到3D布里渊区的BCD----------------------
# 定义tabulators，注意这里用tabulate方法，专门用于计算3D fermi_surface
frmst_tabulators = { "Energy": wberri.calculators.tabulate.Energy(),
               "derberry_curvature" : wberri.calculators.tabulate.DerBerryCurvature(),
             }
# 这里定义计算哪几条能带
frmst_tab_all_grid = wberri.calculators.TabulatorAll(
                    frmst_tabulators,
                    ibands = np.arange(0,8),  # ----** 选择能带
                    mode = "grid"
                        )

frmst_result=wberri.run(system,
                  grid=grid,
                  calculators = {"tabulate" : frmst_tab_all_grid},
                  print_Kpoints = True)
                  
# -----------------保存frmst文件-----------------
frmst_grid_result = frmst_result.results["tabulate"]

frmst_grid_result.write_frmsf( name="GeTe_grid", Ef0=0., quantity="derberry_curvature")

## 具体代码查阅：from wannierberri.result import tabresult
#Energy = frmst_grid_result.get_data(iband=5, quantity='Energy')
#bcd  = frmst_grid_result.get_data(iband=5, quantity='derberry_curvature',component='zz')     # quantity是tabulators中定义的
#print(bcd.shape,Energy.shape)
```

# 看看能不能画在能带上的 BCD: 不能


