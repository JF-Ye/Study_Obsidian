# 概览
- 官方文件： [输入参数连接](https://docs.lammps.org/commands_list.html)
- 教程链接：[点击这里](https://www.bohrium.com/notebook/879b6a3a9d394448913ca1ce7de257ec)
- 中文手册：[lammps中文教程第3版(上册）.pdf](file:///E:/1-%E5%AD%A6%E4%B9%A0%E8%B5%84%E6%96%99/Lammps/lammps中文教程第3版(上册）.pdf)
- 基于 c++ 运行，in 文件中可以直接运行 c++命令，逐行运行
- 输入文件：可以是任意名称，习惯改为 `in.***`
- 实例
```
# bulk water

clear 
dimension 3 
units           metal
boundary        p p p
atom_style      atomic

box tilt large
read_data pos.lmp 
mass            1  78.971
mass            2  183.84


pair_style	deepmd graph.pb
pair_coeff      * *	
neighbor        2.0 bin
neigh_modify    every 10 delay 0 check no


restart 1000 restart.equil   # 每隔1000步保存一次restart


#fix 1 all box/relax x 0.0  y 0.0 vmax 0.001

thermo 10 		# 每隔10次输出热力学信息
thermo_style custom step pe lx ly lz pxx pyy pzz pxy 	# 设置热力学输出的格式
dump q1 all custom 10 dump_*.xyz id type x y z fx fy fz  # 设置 **数据转储** 的规则
#dump_modify q1 element C 
min_style cg 		        # 指定最小化算法的类型
minimize 0 1e-4 10000 50000 	# 用于启动能量最小化过程
undump q1 


print "All done!"
```
# 读取结构 `read_data`
- Lammps 有自带的 exe 执行文件处理 MS 导出的结果
- MS 导出 `*.car; *.cor` 格式文件，生成 `*.car` 和 `*.mdf` 文件
- 将文件导入系统，加载 lammps 环境变量（广州超算：`module load lammps/29Aug2024-gcc-11.4.0-mpich-4.1.2-ch4`）
- 运行 `msi2lmp.exe FeTe_55 -i -class 1 -frc cvff`
- `msi2lmp.exe -help` 查看具体指令意思
# Region
```
region left block -0.939855000 2.060145000 INF INF INF INF
region right block 14.857245000 17.857245000 INF INF INF INF
region bottom INF INF -0.939855000 2.060145000 INF INF
region top INF INF 14.857245000 17.857245000 INF INF
```

# Group
- 将多个原子固定到同一组
```
# 原⼦id为10、25、50的三个原⼦归⼊到sub组
group sub id 10 25 50
# 原⼦id从500到1000的全部原⼦归⼊到sub组
group sub id 500:1000
# 原⼦id为100、110、120...10000的原⼦归⼊到sub组
group sub id 100:10000:10
# 原⼦id⼩于或等于150的原⼦归⼊到sub组
group sub id <= 150
```
- 将多个 region 合并，例如left和right组合并为boundary组：
`group boundary union left right`
# 固定/拉伸晶格
[lammps教程：velocity命令三种使用方法 - 知乎](https://zhuanlan.zhihu.com/p/349336642)
- **Velocity set** 设置原子在特定方向上的速度
- 例如在沿着 Z 轴进行拉伸模拟时，需要把底部原子固定住，使上部（top）原子沿着 Z 轴施加一个速度，可以写为：
- `velocity top set NULL NULL 2  sum yes units box`
- `NULL NULL 2` 表示不设置 x 和 y 方向的速度，仅设置 z 方向速度
- `sum yes` 是将速度 2 加到原子当前时刻速度分量上，如果不写 sum yes，则表示忽略原来的速度，直接将 z 方向速度直接设为 2
- 默认的单位为晶格单位（lattice），units box 关键字可将单位设置为实际速度单位，具体单位与体系 units 有关。