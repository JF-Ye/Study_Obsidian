# 拟合 wannier90 结果
- [pythtb通过读取wannier90输出数据，进行紧束缚模型相关计算 - 哔哩哔哩](https://www.bilibili.com/opus/867788684657688629)
- Wannier90 过程打开 `write_xyz = .true.`
- 需要文件：`wannier90_hr.dat`, `wannier90_centres.xyz`, `wannier90.win`, `wannier90_band.dat(可选)` , `wannier90_band.kpt（可选）`
- 其中， `wannier90.win` 读取：晶格常数begin unit_cell_cart 部分
- `wannier90_centres.xyz` 具体内容参考：[[wannier90_centres.xyz]]
```python
from pythtb import * # import TB model class
import matplotlib.pyplot as plt

mn3sn=w90(r"wann",r"wannier90")

# solve model on a path and plot it
path=[[0.0,0.0, 0.0],[0.5,0.0,0.0], [0.3333,0.33333,0.0], [0.0, 0.0, 0.0]]
# labels of the nodes
k_label=(r'$\Gamma$',r'$M$', r'$K$', r'$\Gamma$')
# call function k_path to construct the actual path
(k_vec,k_dist,k_node)=my_model.k_path(path,101)
#
evals=my_model.solve_all(k_vec)
fig, ax = plt.subplots()
for i in range(evals.shape[0]):
    ax.plot(k_dist,evals[i],"k-")
for n in range(len(k_node)):
    ax.axvline(x=k_node[n],linewidth=0.5, color='k')
ax.set_xlabel("Path in k-space")
ax.set_ylabel("Band energy (eV)")
ax.set_xlim(k_dist[0],k_dist[-1])
ax.set_xticks(k_node)
ax.set_xticklabels(k_label)
fig.tight_layout()
fig.show()
```
# 一、构建模型——以 Kagome 为例
```python
lat=[[1.0,0.0],[0.5,np.sqrt(3.0)/2.0]]
orb=[[0.5,0.],[0.,0.],[0,0.5]]
my_model=tb_model(2,2,lat,orb)
t12 = -2
t13 = -2
t23 = -2
ea = 0
eb = 0
ec = 0
my_model.set_onsite([ea,eb,ec])

my_model.set_hop(t12, 0, 1, [0,0])
```
### `my_model.set_hop(t12, 0, 1, [0,0])`：
- 第一个参数：hopping强度
- 第二、三个参数：$i$ 轨道和 $j$ 轨道
- 第四个参数：跃迁向量 $R$, $[0,0]$ 表示胞内跃迁

$H_{ij}(k) = \sum_{\mathbf{R}} t_{ij}(\mathbf{R}) \exp[i \mathbf{k} \cdot (\mathbf{r}_i - \mathbf{r}_j + \mathbf{R})$