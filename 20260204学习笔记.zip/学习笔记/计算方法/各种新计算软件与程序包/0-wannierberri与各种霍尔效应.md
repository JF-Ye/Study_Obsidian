# 1. 基于 Windows 使用 wannierberri 程序包
## 方法一：
- INCAR 设置 `LWAVE=.T.`
- 将 wannier90 的非自洽步骤产生的 WAVCAR 弄到 windows 本地（自洽的 WAVCAR 不行，此时 wannier90 产生的 WAVCAR 的 K 点数量为 KPOINTS 乘积）
- 在本地文件夹终端运行 `python -m wannierberri.utils.vaspspn` 生成 wannier. spn 文件
- 终端运行 `python -m wannierberri.utils.mmn2uHu wannier90 targets=sHu,sIu` 生成 wannier90.sHu 和 wannier90.sIu 文件
- 补充广州天河超算：`module load python/python3/3.12.10`，`python3 -m wannierberri.utils.vaspspn`
- 最终需要读取四个文件 `wannier90.spn`, `wannier90.mmn`, `wannier90.eig`, `wannier90.chk`
- **注意**：生成 spn 文件需要开 ispin 或 SOC
## 方法二：
- `wannier90.win` 添加参数 `write_tb=.TRUE.` (例如计算非线性霍尔)
- 生成 `wannier90_tb.dat`
```python
import wannierberri as wberri   
system=wberri.System_tb('wannier90_tb.dat',berry=True)
```
 $ nbsphinx-math: frac{partial}{partial k^a} f_0 (\varepsilon_{n: nbsphinx-math: mathbf{k}}) =0 $
## 参数 ：
### tetra
- tetra=False
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202405180927508.png)
- tetra=True
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202405180927784.png)
### adpt_num_iter
- 多次迭代更加精准
## 错误经验
- 要开 ISPIN=2 或加 SOC，否则报错
`npw = int(record(2 + ik * (NBin + 1), 1))，RuntimeError: odd number of coefs 665`
# 2. 计算非线性霍尔效应
[[0-wannierberri脚本]]
**费米面积分法：**
$$D_{ab}^{\mathrm{surf}.}=-\int_{\mathrm{BZ}}{dk\sum_n{\biggl[ \frac{\partial}{\partial k^a}f_0(\varepsilon _{nk}) \biggr] \Omega _{nk}^{b}}}$$
**费米海积分法：**
$$D_{ab}^{\mathrm{sea}.}=\int_{BZ}{dk\sum_n{f_0\left( \epsilon _{nk} \right) \left( \frac{\partial}{\partial k^a}\Omega _{nk}^{b} \right)}}$$
- 需要文件：`wannnier90 - WAVCAR`
- 运行 `python -m wannierberri.utils.vaspspn`，生成 `wanner90.spn` 文件