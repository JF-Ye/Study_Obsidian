- 官网：[点击链接](https://e3nn.org/#tutorial)
- GitHub： [e3nn/e3nn: A modular framework for neural networks with Euclidean symmetry](https://github.com/e3nn/e3nn)
# 概念
- 不变网络：指的是坐标系不变，标量
- 等变：保持对称性，坐标系等变，矢量在变换的坐标系下是等价的