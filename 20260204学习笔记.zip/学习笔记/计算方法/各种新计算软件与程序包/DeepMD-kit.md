官方说明书—— [链接](https://docs.deepmodeling.com/projects/deepmd/en/master/model/train-se-e2-a.html) 
具体每个参数说明书—— [链接](https://docs.deepmodeling.com/projects/deepmd/en/latest/train/train-input.html)
教程 1 CH4：[点击这里](https://www.bohrium.com/notebooks/33539625971)
教程 2 LiCl：[点击这里](https://www.bohrium.com/notebook/879b6a3a9d394448913ca1ce7de257ec)


问题：
1. 是不是必须得计算 AIMD？结构弛豫数据是否可靠？两者有什么区别？
2. AIMD 计算 npt 系综和 nvt 系综有讲究吗？
3. 训练的多节点并行怎么提交脚本，是不是需要分好几个 data
# 步骤
## 一、VASP 先做 AIMD 计算，弛豫也行？
## 二、提取数据，产生训练集和测试集
- 提取 OUTCAR 文件为训练数据脚本
```python
import dpdata
import numpy as np
import math
import sys
import os

# 加载 OUTCAR 格式数据
data = dpdata.LabeledSystem('OUTCAR', fmt = 'vasp/outcar')
data_number = len(data)

# 随机选择10%个索引，用于生成验证集; 剩余其他的数据，用于生成训练集
index_validation = np.random.choice(data_number,size=math.ceil(data_number*0.1),replace=False)   
index_training = list(set(range(data_number))-set(index_validation))

# 创建子数据集：训练集,测试集
data_training = data.sub_system(index_training)
data_validation = data.sub_system(index_validation)

# 导出训练集,测试集（deepmd/npy格式）
data_training.to_deepmd_npy('training_data')
data_validation.to_deepmd_npy('validation_data')

print('# the data contains %d frames' % data_number)
print('# the training data contains %d frames' % len(data_training))
print('# the validation data contains %d frames' % len(data_validation))
```
- 多个 OUTCAR 文件的时候如何合并成一个训练集
```python
import dpdata
from dpdata import LabeledSystem, MultiSystems
from glob import glob
import numpy as np

fs = glob("./*/OUTCAR")  #该提取程序同目录下有多个文件夹中含有OUTCAR文件
data = MultiSystems()
for f in fs:
    print(f"Try to collecte the data from {f}.")
    try:
        ls = LabeledSystem(f,fmt = 'vasp/outcar')
    except:
        print(f)
    if len(ls) > 0:
        data.append(ls)
total_frames = data.get_nframes()
print('# the data contains %d frames' % total_frames)   #所有OUTCAR文件中总数据帧数

# 计算验证集大小（总帧数的10%）
validation_size = int(total_frames * 0.1)
# 训练集大小（剩余90%）
training_size = total_frames - validation_size

# 随机选择验证集数据
index_validation = np.random.choice(total_frames, size=validation_size, replace=False)

# 提取验证集
data_validation = dpdata.MultiSystems()
for idx in index_validation:
    for system_name in data.systems.keys():
        if idx < len(data.systems[system_name]):
            data_validation.append(data.systems[system_name].sub_system([idx]))
            break
        else:
            idx -= len(data.systems[system_name])

# 训练集是除了验证集之外的所有数据
all_indices = np.arange(total_frames)
index_training = np.setdiff1d(all_indices, index_validation)

# 提取训练集
data_training = dpdata.MultiSystems()
for idx in index_training:
    for system_name in data.systems.keys():
        if idx < len(data.systems[system_name]):
            data_training.append(data.systems[system_name].sub_system([idx]))
            break
        else:
            idx -= len(data.systems[system_name])

# 输出训练集和验证集到文件夹
data_training.to_deepmd_npy('training_data')
data_validation.to_deepmd_npy('validation_data')

training_frames = data_training.get_nframes()
validation_frames = data_validation.get_nframes()
print('# the training data contains %d frames' % training_frames) 
print('# the validation data contains %d frames' % validation_frames)
print('# training ratio: %.1f%%, validation ratio: %.1f%%' % 
      (training_frames/total_frames*100, validation_frames/total_frames*100))

# 检查，判断有没有数据重叠---------------
valdata = np.load("./validation_data/Fe4Te4/set.000/box.npy")
tradata = np.load("./training_data/Fe4Te4/set.000/box.npy")
print(np.shape(valdata))
print(np.shape(tradata))
val_rows = {tuple(row) for row in valdata}
tra_rows = {tuple(row) for row in tradata}
# 求交集
overlap = val_rows & tra_rows
print(f"重复的行数: {len(overlap)}")
if len(overlap) > 0:
    print("重复的行如下：")
    for r in overlap:
        print(r)
else:
    print("没有任何重叠的行。")

```
## 三、设置 `input.json` 文件，进行模型训练
- 官方说明书—— [链接](https://docs.deepmodeling.com/projects/deepmd/en/master/model/train-se-e2-a.html)
- 具体每个参数说明书—— [链接](https://docs.deepmodeling.com/projects/deepmd/en/latest/train/train-input.html)
- 运行命令：`dp train input.json`
```
{
    "_comment": " model parameters",
    "model": {
	"type_map":	["Fe", "Te"],
	"descriptor" :{
	    "type":		"se_e2_a",
	    "sel":		[120, 120],
	    "rcut_smth":	0.50,
	    "rcut":		10.00,
	    "neuron":		[25, 50, 100],
	    "resnet_dt":	false,
	    "type_one_side":    true,
	    "axis_neuron":	16,
	    "seed":		1,
	    "_comment":		" that's all"
	},
	"fitting_net" : {
	    "neuron":		[240, 240, 240],
	    "resnet_dt":	true,
	    "seed":		1,
	    "_comment":		" that's all"
	},
	"_comment":	" that's all"
    },

    "learning_rate" :{
	"type":		"exp",
	"decay_steps":	5000,
	"start_lr":	0.001,	
	"stop_lr":	3.51e-8,
	"_comment":	"that's all"
    },

    "loss" :{
	"type":		"ener",
	"start_pref_e":	0.02,
	"limit_pref_e":	1,
	"start_pref_f":	1000,
	"limit_pref_f":	1,
	"start_pref_v":	0.2,
	"limit_pref_v":	1,
	"_comment":	" that's all"
    },

    "training" : {
	"training_data": {
	    "systems":     ["../00.data/training_data"],
	    "batch_size":  "auto",
	    "_comment":	   "that's all"
	},
	"validation_data":{
	    "systems":	   ["../00.data/validation_data"],
	    "batch_size":  1,
	    "numb_btch":   3,
	    "_comment":	   "that's all"
	},
	"numb_steps":	400000,
	"seed":		10,
	"disp_file":	"lcurve.out",
	"disp_freq":	100,
	"save_freq":	1000,
	"_comment":	"that's all"
    },    

    "_comment":		"that's all"
}


```
### `descriptor` 原子信息描述符
- `rcut`：截断半径，超过此半径的原子不考虑，单位Å
- `rcut_smth`： 平滑起点，避免梯度不连续
- `sel`：决定每种元素最多考虑多少个近邻原子
- 👆这里可以扩胞 $3\times3$，看看半径多大，有多少个原子
- `neuron`：表示嵌入网络（embedding net）的层结构，每层的神经元个数依次为 25 → 50 → 100
### `fitting_net` 拟合网络
- `neuron`：神经网络的层结构，表示隐藏层
- `resnet_dt`：使用残差网络
###  `learning_rate` 学习精度
- "type":		"exp",
- "decay_steps":	 这里值设为训练步数numb_steps/200
- "start_lr":	0.001
- "stop_lr":	3.51e-8
### `loss` 损失函数
- `start_pref_e` / `limit_pref_e`：初始/最终**能量**权重
- `start_pref_f` / `limit_pref_f`：初始/最终**力**权重
- `start_pref_v` / `limit_pref_v`：初始/最终**应变**权重
## 四、冻结模型与数据处理
### 1. 处理 `lcurve.out` 文件
- 运行完训练模型 `dp train input.json` 后，会产生 `lcurve.out` 文件输出训练结果。
- `lcurve.out` 文件从左到右依次是：1. 训练步数  2. 验证损失  3. 训练损失  4. 能量的均方根（RMS）验证误差  5. 能量的 RMS 训练误差  6. 力的 RMS 验证误差  7. 力的 RMS 训练误差  8. 学习率
- 学习率是机器学习中的一个重要概念。在 DP 模型中，学习率会经历一个从大到小指数衰减的过程。这样既能保证模型收敛的效率，也能保证模型的精度。因此在学习率的参数中，有起始学习率和结束学习率两种。在上面的例子中，我们将起始学习率 `start_lr`、结束学习率 `stop_lr` 和学习率的衰减步长 `decay_steps` 分别设置为 0.001，3.51e-8，和 5000，那么模型学习率会从 0.001 开始，每 5000 步降低一点，直到降低到 3.51e-8（或者训练结束）为止。
- 损失函数可视化，主要看能量和力的部分（4-7 列）
```python
import numpy as np
import matplotlib.pyplot as plt

data = np.genfromtxt("./lcurve.out", names=True)
for name in data.dtype.names[1:-1]:	# 列名，第二列到倒数第二列
    plt.plot(data['step'], data[name], label=name)
plt.legend()
plt.xlabel('Step')
plt.ylabel('Loss')
plt.yscale('log')
#plt.show()
plt.savefig("lcurve.png", dpi=300, bbox_inches='tight')  
plt.close()  
```
### 2. 模型处理
- `dp freeze -o graph.pb`： 冻结模型
- `dp compress -i graph.pb -o compress.pb`：压缩模型以提高计算速度
- `dp test -m graph.pb -s ../00.data/validation_data -n 100 -d result`： 检查模型训练质量，获得 MAE、RMSE 等数据，生成 `results.e.out`，`results.f.out`, `results.v.out` 等文件。
- 将预测数据和原始数据可视化
```python
import numpy as np
import matplotlib.pyplot as plt

# 定义绘制散点图和对角线的函数
def plot(ax, data, key, xlabel, ylabel, min_val, max_val):
    data_key = f'data_{key}'
    pred_key = f'pred_{key}'
    ax.scatter(data[data_key], data[pred_key], label=key, s=6)
    ax.legend()
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_xlim(min_val, max_val)
    ax.set_ylim(min_val, max_val)
    ax.plot([min_val, max_val], [min_val, max_val], 'r', lw=1)

# 读取数据，并对e数据进行原子化处理
natom = 64
data_e = np.genfromtxt("./results.e.out", names=["data_e", "pred_e"])
data_f = np.genfromtxt("./results.f.out", names=["data_fx", "data_fy", "data_fz", "pred_fx", "pred_fy", "pred_fz"])

for col in ['data_e', 'pred_e']:
    data_e[col] /= natom

# 计算e和f的最小值和最大值
data_e_stacked = np.column_stack((data_e['data_e'], data_e['pred_e']))
data_f_stacked = np.column_stack((data_f['data_fx'], data_f['data_fy'], data_f['data_fz'], data_f['pred_fx'], data_f['pred_fy'], data_f['pred_fz']))

min_val_e, max_val_e = np.min(data_e_stacked), np.max(data_e_stacked)
min_val_f, max_val_f = np.min(data_f_stacked), np.max(data_f_stacked)

# 绘制散点图并保存结果
fig, axs = plt.subplots(1, 2, figsize=(12, 5))
plot(axs[0], data_e, 'e', 'DFT energy (eV/atom)', 'DP energy (eV/atom)', min_val_e, max_val_e)

for force_direction in ['fx', 'fy', 'fz']:
    plot(axs[1], data_f, force_direction, 'DFT force (eV/Å)', 'DP force (eV/Å)', min_val_f, max_val_f)

plt.savefig("dp&dft1.png", dpi=300, bbox_inches='tight')  # 保存图片
plt.close()  
```
## 五、使用 LAMMPS 进行 MD 计算
- 复制压缩的 `pb` 模型到新的文件夹中，`cp ../01.train/licl-compress.pb ./`
- 在 `in.lammps` 文件中添加如下代码
```
atom_style  atomic

pair_style  deepmd graph.pb
pair_coeff  * *
```