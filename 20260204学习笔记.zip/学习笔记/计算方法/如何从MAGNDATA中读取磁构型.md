例子：[CrSe](https://www.cryst.ehu.es/magndata/index.php?this_label=2.35)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171146908.png)
- 该结构并非其 non-magnetic 原胞
- 放入 MS，导入对称性可得
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171148189.png)
- 扩胞 $3\times3$
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171155257.png)
- 定义晶格基矢，切胞
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171157026.png)
- 根据表格设置磁矩
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171217197.png)
- 转换成笛卡尔坐标输入 INCAR（find_spingroup 是**Modulus along axes**）
![0e38a4c3ff3a397d457cbace15c5c8d.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171218907.png)
## 其中磁性旋转对称
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507171223649.png)
其中， $-y,x-y,z,+1$ 操作表示顺时针旋转 120 度
逆时针旋转矩阵 $$\left[ \begin{matrix}
	cos(\theta )&		-sin(\theta )\\
	sin(\theta )&		cos(\theta )\\
\end{matrix} \right] $$
顺时针旋转矩阵 $$\left[ \begin{matrix}
	cos(2\pi-\theta )&		-sin(2\pi-\theta )\\
	sin(2\pi-\theta )&		cos(2\pi-\theta )\\
\end{matrix} \right] =\left[ \begin{matrix}
	cos(\theta )&		sin(\theta )\\
	-sin(\theta )&		cos(\theta )\\
\end{matrix} \right] $$
旋转矩阵代码
```
import numpy as np

# Define the rotation matrix for -60° (clockwise rotation)
R = np.array([
    [0.5, -np.sqrt(3)/2, 0],
    [np.sqrt(3)/2, 0.5, 0],
    [0, 0, 1]
])

# Define the vector
v = np.array([-0.975, -1.68875, 2.9])

# Perform the multiplication
result = R.dot(v)

formatted_result = [f"{x:.5g}" for x in result]

print("Result with 5 significant figures:", formatted_result)

```

