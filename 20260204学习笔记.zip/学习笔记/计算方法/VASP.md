# 加 U
[科学网—VASP加U考虑强关联相互作用 - 叶小球的博文](https://blog.sciencenet.cn/blog-567091-775079.html)
- LDAU= .TRUE.|. FALSE.：开启/关闭+U 功能，默认值为. FALSE.
- LDAUTYPE=1|2|4 指的是+U 的类型，默认值是 2；其中 1 为 Liechtenstein 等提出的旋转不变 LSDA+U 方法；2 为 Dudarev 等提出的简化 LSDA+U 方法；4 与 1 类似, 但不考虑 LSDA 交换劈裂；
- LDAUL=-1|1|2|3 分别对应不加 U、p、d、f 轨道加 U
- LDAUU、LDAUJ 分别指定电子库伦相互作用项和交换相互作用项（U 和 J 值）；
- LMAXMIX =2/4/6：默认为 2，加 U 计算时该值需大于轨道量子数，对于含有 d 轨道或 f 轨道电子的体系需对应增加至 4 或 6。
```
LDAU    = .TRUE.
LDAUTYPE= 2
LDAUL   = -1 2 -1
LDAUU   = 0 4.0  0
LDAUJ   = 0.0 0 0
LDAUPRINT = 2
LMAXMIX = 4
```
# 非共线磁性
```
ISPIN = 2
LNONCOLLINEAR = .TRUE.
MAGMOM = ***** # 笛卡尔坐标，即直角坐标系
```
# 计算费米面
1. 高精度弛豫
2. 计算费米面
	- INCAR 参数与自洽计算一致
	- Vaspkit-261 生成计算费米面的 KPOINTS
3. 运行计算
4. Vaspkit-262 生成包含费米面数据的 `FERMISURFACE.bxsf` 文件
# ISMEAR 选择
[官方连接](https://www.vasp.at/wiki/index.php/Smearing_technique)
- `ISMEAR=0`: 高斯方法，半导体/绝缘体使用
- `ISMEAR=1`: MP 方法，金属使用
- 尽可能设置大 SIGMA，但同时保证 OUTCAR 中 `entropy T*S    EENTRO` 除以原子数，小于 0.001

# 非共线磁计算——约束磁矩方向
官方链接：[点击这里](https://www.vasp.at/wiki/index.php/Constraining_local_magnetic_moments)
- What can one do when convergence is bad:
    - 先用非磁结构（`ISPIN=1`），用 ` ISTART=0 ` 或 ` ICHARG=1 ` 生成 CHGCAR 或 WAVECAR ,读取文件再做磁性计算。Start from charge density of non-spin-polarized calculation using [ISTART](https://www.vasp.at/wiki/index.php/ISTART "ISTART")=0 (or remove the [WAVECAR](https://www.vasp.at/wiki/index.php/WAVECAR "WAVECAR") file) and [ICHARG](https://www.vasp.at/wiki/index.php/ICHARG "ICHARG")=1.
    - Use linear mixing by setting [BMIX](https://www.vasp.at/wiki/index.php/BMIX "BMIX")=0.0001 and [BMIX_MAG](https://www.vasp.at/wiki/index.php/BMIX_MAG "BMIX MAG")=0.0001.
    - Mix slowly, i.e., reduce [AMIX](https://www.vasp.at/wiki/index.php/AMIX "AMIX") and [AMIX_MAG](https://www.vasp.at/wiki/index.php/AMIX_MAG "AMIX MAG").
    - REDUCE [MAXMIX](https://www.vasp.at/wiki/index.php/MAXMIX "MAXMIX"), the number of steps stored in the Broyden mixer (default [MAXMIX](https://www.vasp.at/wiki/index.php/MAXMIX "MAXMIX")=45).
    - Restart from partially converged results (stop a calculation after say 20 steps and restart from the [WAVECAR](https://www.vasp.at/wiki/index.php/WAVECAR "WAVECAR") file).
    - Use constraints to stabilize the magnetic configuration.
## 关键步骤：添加惩罚势能
```
I_CONSTRAINED_M = 1		# 1：约束方向；2：约束方向和大小
M_CONSTR =		# 跟MAGMOM一样，磁矩约束的大小和方向设置
RWIGS = 1.0		# 设置积分半径来确定局部矩，一般参照元素的共价半径修改。注意：                            要关掉LORBIT
LAMBDA = 10		# 惩罚函数的权重，增大会增加运行时间
```
- $E_p$ 是惩罚函数的能量，随 `LAMBDA` 增大而减小
- [I_CONSTRAINED_M - VASP Wiki](https://www.vasp.at/wiki/index.php/I_CONSTRAINED_M)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507081146545.png)
RWIGS 设置：
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202507081151222.png)
## 提示
- MAGMOM 最好从比较局域的（比较大的）值开始计算，如实验值的 1.2~1.5 倍，因为默认值有时不够安全（不容易收敛）。
**MAGMOM 只在如下两种情况下有效：**
- （1）不读取 WAVECAR 和 CHGCAR 的计算。
- （2）从 non magnetic 的 WAVECAR 和 CHGCAR 开始的计算。如果你在使用 MAGMOM 计算的时候发现磁矩很难收敛到你想要的结果，可以尝试先进行 non-magnetic 的计算，然后再从 non-magnetic 的 WAVECAR 和 CHGCAR 开始（`ICHARG=1`)，加入磁矩再进行计算。
# 加压 
`PSTRESS`
- 单位：kB (10 kB=1 Gpa)
- 结构优化的时候开启
# 静电势
- 静电势（ESP）描述了一个单位正电荷在分子周围不同位置所感受到的电势能 —— 正电荷倾向于向低电势区域移动，负电荷则反之。数学上，其简化表达式为库仑势的叠加
- INCAR 添加 `LVHAR = .TRUE.` 和 `LCHARG=.T.` 产生 LOCPOT 和 CHGCAR 文件
- 进行自洽
- 数据处理
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202509180938755.png)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202510041631365.png)
# 电子局域函数 (ELF, Electron locational fuction)
- ELF的值在０到1之间，取上限值1表示电子完全局域化，而0值可能表示电子完全离域化，而ELF=0.5这个中间值则表示该处电子形成了类似于电子气的电子对分布。因此常常通过ELF来判断原子间成键类型
- 自洽添加参数： `LELF = .TRUE.`

# 加电场
```
EFIELD=0.5    # 0.5 V/ai
LDIPOL = .TRUE.  # 开启偶极矩修正
IDIPOL = 3       # 沿z轴加电场 
ISYM=0     # 不知道有什么影响
```
- 开始电场小一点，逐渐加大电场
# AIMD
- 教程：[点击这里](https://www.bilibili.com/video/BV1UeW6eLEgm/?spm_id_from=333.337.search-card.all.click&vd_source=ba4763a59109489ffb209fd63a8b7c0c)
- 首先要**扩胞**!!!!！$4\times4$
## **NVT** 系综：表示 **粒子数（N）、体积（V）、温度（T）** 恒定的系综。
- 官方链接：[点这里](https://www.vasp.at/wiki/NVT_ensemble)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202510132311722.png)

```
 IBRION = 0                   # choose molecular dynamics 
 MDALGO = 2                   # use Nose-Hoover thermostat 
 ISIF = 2                     
 TEBEG = 300                  # set temperature 
 NSW = 100000                  # number of time steps 
 POTIM = 2.0                  # time step in femto seconds 
 SMASS = 0                  # setting the virtual mass for the Nose-Hoover 
 ISYM=0
 POTIM=2
 
 LREAL=Auto
```
## **NPT** 系综：表示  **粒子数（N）、压力（P）、温度（T）** 恒定的系综。
- 类似弛豫，没必要
- 官方链接：[点这里](https://www.vasp.at/wiki/index.php/NpT_ensemble)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202510132311031.png)
## 参数设置
```INCAR
 IBRION = 0                      # choose molecular-dynamics 
 MDALGO = 3                      # using Langevin thermostat
 ISIF = 3                        
 TEBEG = 300                     # set temperature 
 NSW = 10000                     # number of time steps 
 POTIM = 2.0                     # time step in femto seconds 
 LANGEVIN_GAMMA =100 100 100 100 #几种原子就设置几个
 LANGEVIN_GAMMA_L = 100           #一直默认
 PMASS = 100            # the fictitious mass of the lattice degrees of freedom
 
 LREAL=Auto
 
```
系综选择：
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202510132332018.png)
- 续算：把CONTCAR改成POSCAR。INCAR中的NSW改成剩余步数。其余不变重新提交
# 压电系数
-  [如何计算二维材料压电系数（以单层MoS2为例） - 知乎](https://zhuanlan.zhihu.com/p/556222283)
```
NSW = 1			# 设0会没有IONIC部分
LEPSILON = .TRUE.         # 打开压电计算
LPEAD=.TRUE.		# 不设容易报错，设了不影响
IBRION = 8                # 利用密度泛函微扰法进行计算


# IVDW 要注释
# NPAR 要注释
```
- 压电常数与**应力T**、**应变S**，**电场强度E**、**电位移D**有关
- 下标中的第一个数字指的是**电场方向**，第二个数字指的是**应力或应变的方向**
-  **压电应变常数 $d_{ij}$**：当压电体处于恒定应力作用时，由于电场强度变化所产生的应变变化与电场强度变化之比；或在恒定电场作用时，由于应力变化所产生的电位移变化与应力变化之比，其单位为 $C/N$ 或 $m/V$，其表示式为 ：
$$d_{ij}=(\frac{\partial E_i}{\partial S_j})T=(\frac{\partial D_i}{\partial T_j})E$$
- **压电应力常数 $e_{ij}$：** 当压电体受恒定应变作用时，由于电场强度变化所产生的应力变化与电场强度变化之比; 或受恒定电场作用时，由于应变变化所产生的电位移变化与应变变化之比，其单位为$N/Vm$或$C/m^2$
$$e_{ij}=(-\frac{\partial T_i}{\partial E_j})S=(\frac{\partial D_i}{\partial S_j})E$$
$$
e_{ij}=d_{ij}C_{ij}
$$
$$\left( \begin{matrix}
	e_{11}&		e_{12}&		e_{16}\\
	e_{21}&		e_{22}&		e_{26}\\
	e_{31}&		e_{32}&		e_{36}\\
\end{matrix} \right) =\left( \begin{matrix}
	d_{11}&		d_{12}&		d_{16}\\
	d_{21}&		d_{22}&		d_{26}\\
	d_{31}&		d_{32}&		d_{36}\\
\end{matrix} \right) \left( \begin{matrix}
	C_{11}&		C_{12}&		C_{16}\\
	C_{21}&		C_{22}&		C_{26}\\
	C_{31}&		C_{32}&		C_{36}\\
\end{matrix} \right) $$
- 单位转换
$$
C / m^{2} * Å=C / m^{2} * 10^{-10} m=10^{-10} C / m=10^{2} p C / m
$$$$1 bar=100000 Pa=10000 N/m^2$$