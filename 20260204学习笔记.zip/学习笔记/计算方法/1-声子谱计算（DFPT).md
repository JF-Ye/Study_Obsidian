[VASP+phonopy计算声子_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV1gC4y187bu/?vd_source=bcd8fc258c9a008fbb139cb304137c6d)
## 前期工作：
- 结构高精度弛豫
```
EDIFF=1E-8
EDIFFG=-0.001
ENCUT=高值
```

## 声子谱计算
- **POSCAR** 设置
```
mv POSCAR POSCAR-unitcell
phonopy -d --dim='2 2 2' -c POSCAR-unitcell
mv SPOSCAR POSCAR
```
- **INCAR** 设置
```
IBRION=8 (无范德华力)
IBRION=6 (有范德华力)

NSW=1
ADDGRID=.TRUE.

注释ISYM
注释NPAR
更改MAGMOM（超胞）
```
- 提交任务
## 声子谱数据提取
- [**band.conf**](https://phonopy.github.io/phonopy/setting-tags.html#band-and-band-points)设置
```
ATOM_NAME = Ca Pd 
DIM = 2 2 2
BAND = 0 0 0 0.5 0 0 1/3 1/3 0 0 0 0 0 0 0.5
BAND_LABELS = G M K G Z
FORCE_CONSTANTS = READ
BAND_POINTS = 101
PRIMITIVE_AXES=Auto
EIGENVECTORS=.TRUE.   # 声子振动模式可视化必设参数
BAND_CONNECTION=.TRUE.
```
- 提取数据
```
phonopy --fc vasprun.xml
phonopy --dim="2 2 2" -c POSCAR-unitcell band.conf 
phonopy-bandplot --gnuplot > phonon.out
```
## 声子振动模式可视化
网址：[TSS Physics - Visualization of phonons (henriquemiranda.github.io)](https://henriquemiranda.github.io/phononwebsite/phonon.html)
需要文件: `band.yaml`
## 声子谱理论
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202404262248995.png) 

- 光学支：k->0 时为一个常数。表示一种局域振动模式（类似分子振动），有一个固定的振动频率，固在 k->0 时有一个固定的值。
- 声学支：k->0 时，频率正比于 k。表示一种集体振动，所有格子都参与。
参考链接：[刘海文 2020 固体理论 P9](https://www.bilibili.com/video/BV1J14y1y7ya?p=9&spm_id_from=pageDriver&vd_source=bcd8fc258c9a008fbb139cb304137c6d)
# 二、 `yaml` 文件分析
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412291538282.png)
- 实部需要除以：原子质量开根号
# 有限位移法
- 建立disp-*文件夹，具体数量以生成POSCAR-*的数量决定。将POSCAR-POTCAR, INCAR, KPOINTS放入disp-*文件夹
```
mkdir disp-001  
cp POSCAR-001 ./disp-001/POSCAR  
cp POTCAR ./disp-001/POTCAR  
cp INCAR ./disp-001/INCAR  
cp KPOINTS ./disp-001/KPOINTS
```
- INCAR 设置：跟自洽一样
```
NSW=0
IBRION=-1
```
- 分别在不同的文件夹完成自洽计算
- 设置 `band.conf` 文件，这里关键更改如下参数，其余一样
```
FORCE_CONSTANTS = WRITE
```
- 终端运行命令：
```
phonopy -f 00*/vasprun.xml
phonopy --dim="2 2 1" -c POSCAR-unitcell band.conf
phonopy-bandplot --gnuplot > phonon.out
```