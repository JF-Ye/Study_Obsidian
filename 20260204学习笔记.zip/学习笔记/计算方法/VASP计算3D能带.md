- 主要针对要投影非共线自旋方向的能带方向的计算
# 一、生成布里渊区 K 点主
- 主要针对二维体系，取 $k_z=0$ 的 K 点
- K 点规则链接：[点击这里](https://zhuanlan.zhihu.com/p/497420253)，最多 K 点可能只有 $101\times101$ 附近，再密的话需要考虑对称性了
```
import numpy as np

nk = 101  # 网格密度
k = np.linspace(-0.5, 0.5, nk)
kx, ky = np.meshgrid(k, k)

# 构造第三列为 0，第四列为 1
kz = np.zeros_like(kx)
w = np.ones_like(kx)

# 合并所有列为 (N, 4)
points = np.column_stack((kx.ravel(), ky.ravel(), kz.ravel(), w.ravel()))
total_points = points.shape[0]

# 写入 KPOINTS 文件
with open("KPOINTS", "w") as f:
    f.write("KPOINT Generate by Jiefeng Ye\n")
    f.write(f"{total_points}\n")
    f.write("Reciprocal lattice\n")
    np.savetxt(f, points, fmt="% .8f")

print(f"KPOINTS 文件已生成，共 {total_points} 个点。")
```
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202511031138742.png)
- 提交 VASP 计算
# 二、提取 PROCAR，运行脚本 `read_procar.py`
```python
# 处理PROCAR文件，提取需要的数据，用于3D能带作图，包含非共线的自旋极化投影
# 需要文件：PROCAR
# 需要确定用于绘图的能带：band_index, LORBIT
# 2025.11.03, Jiefeng Ye

import numpy as np
import os
import re

# 文件路径
procar_path = 'PROCAR'
# 提取的能带索引
band_index = 106
LORBIT=10

if LORBIT == 10:
    l_index = 4
elif LORBIT == 11:
    l_index = 10

# 存储提取的行
kpoint_lines = []
band_lines = []
proj_lines = []
kxyz = []
energy = []
occupy = []

def fix_coordinate_format(line):
    """修正坐标格式，在x和y中间添加空格"""
    return re.sub(r'(?<=\d)-(?=\d)', ' -', line)


# 读取文件并提取目标行
print("开始读取PROCAR文件并提取目标行...")

with open(procar_path, 'r', encoding='utf-8') as f:
    current_band = None  # 用于跟踪当前正在读取的能带
    collecting_proj = False  # 用于标记是否正在收集投影数据
    
    for line_number, line in enumerate(f, 1):
        # 去除行首尾空白字符
        stripped_line = line.strip()
        if not stripped_line:
            continue
        
        # 按空白字符分割行
        words = stripped_line.split()
        if not words:
            continue
        
        # 解决坐标有"负"连在一起的问题
        # 检查首单词是否为'k-point'
        if words[0] == 'k-point':
            if len(words) == 9:
                kpoint_lines.append((line_number, line.rstrip()))
                kxyz.append([float(words[3]), float(words[4]), float(words[5])])
            elif len(words) == 8:
                new_line = fix_coordinate_format(line.rstrip())
                kpoint_lines.append(new_line)
                new_words = new_line.strip().split()
                kxyz.append([float(new_words[3]), float(new_words[4]), float(new_words[5])])
            else:
                print(f"error: {line}")
                print(len(words))
            
        # 处理x, y, z方向投影，只收集指定能带的投影数据
        if line_number == 2:
            nums = re.findall(r"\d+", line)
            if len(nums) >= 2:
                totalk, totalb = nums[0], nums[1]
        
        # 检查是否包含'band'（注意空格数量可能变化）
        if len(words) >= 2 and words[0] == 'band':
            # 如果遇到新的band行，关闭之前的收集状态
            collecting_proj = False
            try:
                new_band = int(words[1])
                # 如果是目标能带，开启收集状态并保存能带信息
                if new_band == band_index:
                    collecting_proj = True
                    band_lines.append(line.rstrip())
                    energy.append(float(words[4]))
                    occupy.append(float(words[7]))
            except ValueError:
                print(f"Warning: 无法解析能带编号: {words[1]}")
                continue
        
        # 如果正在收集投影数据，并且行以tot开头
        elif collecting_proj and line.strip().startswith("tot"):
            parts = line.split()
            if len(parts) >= l_index:
                proj_lines.append(float(parts[l_index]))

# 打印数据读取统计信息
print("\n=== 数据读取统计 ===")
print(f"总行数: {line_number}")
print(f"k点数量: {len(kpoint_lines)}")
print(f"能带 {band_index} 的能量值数量: {len(band_lines)}")
print(f"能带 {band_index} 的xyz方向投影数量: {len(proj_lines)}")

#################################################################
#################################################################
# 保存提取的行到文件
# 保存单独K点文件===============================================
with open(f'3D_kpoints_{band_index}.dat', 'w', encoding='utf-8') as f:
    f.write("# k-point {len(kpoint_lines)}行\n")
    for content in kpoint_lines:
        f.write(f"{content}\n")
print(f"k-point行已保存到 3D_kpoints_{band_index}.dat")

# 保存单独能带文件===============================================
with open(f'3D_energy_{band_index}.dat', 'w', encoding='utf-8') as f:
    f.write(f"# band {band_index} {len(band_lines)}行\n")
    for content in band_lines:
        f.write(f"{content}\n")
print(f"band {band_index} energy已保存到 3D_energy_{band_index}.dat")

# 保存单独的x, y, z方向投影文件===============================================
xdata, ydata, zdata = [], [], []
for i, val in enumerate(proj_lines, start=1):
    mod = i % 4
    if mod == 2:
        xdata.append(val)
    elif mod == 3:
        ydata.append(val)
    elif mod == 0:
        zdata.append(val)

header = f"# {totalk} {totalb}\n"
header += "# x           y           z\n"  # 添加列标题
with open(f"3D_xyz_proj_{band_index}.dat", "w", encoding="utf-8") as f:
    f.write(header)
    # 使用zip将三个列表打包在一起遍历
    for x, y, z in zip(xdata, ydata, zdata):
        f.write(f"{x:12.6f}  {y:12.6f}  {z:12.6f}\n")
print(f"band {band_index} xyz_proj已保存到 3D_xyz_proj_{band_index}.dat")

# 保存完整的3D能带绘图文件===============================================
with open(f"3Dband_plot_{band_index}.dat", "w", encoding="utf-8") as f:   
    # 写入表头，包含所有数据列的说明
    f.write("# kx         ky         kz         energy     occupy     proj_x     proj_y     proj_z\n")
    # 使用zip将所有数据列打包在一起遍历
    for (kx, ky, kz), e, occ, px, py, pz in zip(kxyz, energy, occupy, xdata, ydata, zdata):
        f.write(f"{kx:12.6f}  {ky:12.6f}  {kz:12.6f}  {e:10.6f}  {occ:8.4f}  {px:10.6f}  {py:10.6f}  {pz:10.6f}\n")
print(f"完整的3D能带数据（包含k点、能量、占据数和xyz投影）已保存到 3Dband_plot_{band_index}.dat")
```