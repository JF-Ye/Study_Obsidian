[Berry Phases – Page 124](zotero://open-pdf/library/items/5BNM86TW?page=124)   
推导过程：[wannier函数推导.afx](file:///E:/Obsidian笔记/学习笔记/00_物理公式推导记录留存/wannier函数推导.afx)
[经典文章Rev. Mod. Phys.：Maximally localized Wannier functions: Theory and applications](zotero://open-pdf/library/items/QLA322ZE?page=1)
# 一、基本知识
- Wannier 函数：
$$|w_{n\mathbf{R}}\rangle =\frac{V_{\mathrm{cell}}}{(2\pi )^3}\int_{\mathrm{BZ}}{e^{-i\mathbf{k}\cdot \mathbf{R}}|\psi _{n\mathbf{k}}\rangle d^3k}
\tag{书 3.80}
$$
- Wannier 函数简记的狄拉克表示：
$$\left| \mathbf{R}n \right> =\frac{V}{\left( 2\pi \right) ^3}\int_{\mathrm{BZ}}{d\mathbf{k}e^{-i\mathbf{k}\cdot \mathbf{R}}\left| \psi _{n\mathbf{k}} \right>}
\tag{Rev. Mod. Phys. 3}
$$
所以，有 $\left| \mathbf{R}n \right> =|w_{n\mathbf{R}}\rangle$
- 离散情况下的公式转换有：
$$\int_{\mathrm{BZ}}{d^3k}=\sum_{\mathbf{k}}{\Delta k}=\sum_{\mathbf{k}}{\frac{\mathrm{V}_{\mathrm{BZ}}}{N_k}}=\sum_{\mathbf{k}}{\frac{(2\pi )^3}{V_{\mathrm{cell}}}\frac{1}{N_k}}$$
- 离散 wannier 函数：
$$|n\mathbf{R}\rangle =\frac{1}{N_k}\sum_{\mathbf{k}}{e^{-i\mathbf{k}\cdot \mathbf{R}}|\psi _{n\mathbf{k}}\rangle}\tag{Rev. Mod. Phys. 12}$$
- 归一化后：
$$ |n\mathbf{R}\rangle =\frac{1}{\sqrt{N}}\sum_{\mathbf{k}}{e^{-i\mathbf{k}\cdot \mathbf{R}}|\psi _{n\mathbf{k}}\rangle}
\tag{Rev. Mod. Phys. 14}$$
- 位置算符：
$$\langle \mathbf{R}n|\mathbf{r}|\mathbf{0}m\rangle =i\frac{V}{(2\pi )^3}\int{d\mathbf{k}e^{i\mathbf{k}\cdot \mathbf{R}}\langle u_{n\mathbf{k}}|\nabla _{\mathbf{k}}|u_{m\mathbf{k}}\rangle}
\tag{Rev. Mod. Phys. 23}
$$
$$\langle \mathbf{R}n|\mathbf{r}|\mathbf{0}m\rangle =i\frac{1}{N_k}\sum_{\mathbf{k}}{e^{i\mathbf{k}\cdot \mathbf{R}}\langle u_{n\mathbf{k}}|\nabla _{\mathbf{k}}|u_{m\mathbf{k}}\rangle}$$
- Wannier centers 为在原胞 $\mathbf{R}=\mathbf{0}$ 的电子位置：
$$\bar{\mathbf{r}}=\mathbf{r}_n=\langle \mathbf{0}n|\mathbf{r}|\mathbf{0}n\rangle =\frac{V}{(2\pi )^3}\int_{\mathrm{BZ}}{dk\langle \tilde{u}_{n\mathbf{k}}|i\nabla _{\mathbf{k}}|\tilde{u}_{n\mathbf{k}}\rangle}
\tag{Rev. Mod. Phys. 88}$$
- 其中，$\left| \tilde{u}_{n\mathbf{k}} \right. \rangle$ 为布洛赫波的 gauge freedom 项（任意规范）
$$\begin{aligned}
	\left| \tilde{u}_{n\mathbf{k}} \right. \rangle &=e^{i\varphi _n\left( \mathbf{k} \right)}\left| u_{n\mathbf{k}} \right. \rangle 
	\\
	\left| \tilde{\psi}_{n\mathbf{k}} \right. \rangle &=e^{i\varphi _n\left ( \mathbf{k} \right)}\left| \psi _{n\mathbf{k}} \right. \rangle 
\end{aligned}	\tag{Rev. Mod. Phys. 7}$$
