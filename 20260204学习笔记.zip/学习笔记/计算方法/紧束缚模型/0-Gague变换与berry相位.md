[Berry Phases – Page 130](zotero://open-pdf/library/items/5BNM86TW?page=130)   
微信公众号： **绝热定理与Berry相位【凝聚态物理中的拓扑效应-01】**  
推导过程：[berry 与拓扑推导.afx](file:///E:/Obsidian笔记/学习笔记/00_物理公式推导记录留存/berry与拓扑推导.afx)  
# 一、规范变换
- 量子力学中波函数的**绝对相位**通常是没有物理意义的，这是因为波函数 $|\psi _{nk}\rangle$ 与 $|\psi _{nk}\rangle e^{i\phi}$ 得到的可观测量 $\langle \phi|A|\phi \rangle$ 是一样的
- $|\psi _{nk}\rangle$ 与 $|\psi _{nk}\rangle e^{i\phi}$ 之间差了相位 $\phi$ ，波函数相位的变换称为规范变换（Gauge transformation）
$$
|\psi ^{\prime}\left( \boldsymbol{R} \right)\rangle =e^{i\alpha (\mathbf{R})}|\psi \left( \boldsymbol{R} \right) \rangle
$$
- 几何相位：
$$\gamma _n\left( t \right) =i\int_{\boldsymbol{R}_{\boldsymbol{i}}}^{\boldsymbol{R}_{\boldsymbol{f}}}{\langle \psi _n\left( \boldsymbol{R} \right) |\nabla _{\boldsymbol{R}}|\psi _n\left( \boldsymbol{R} \right) \rangle}\cdot d\boldsymbol{R}$$
- 经过规范变换 $|\psi \left( \boldsymbol{R} \right) \rangle \rightarrow |\psi ^{\prime}\left( \boldsymbol{R} \right) \rangle =e^{i\alpha (\mathbf{R})}|\psi \left( \boldsymbol{R} \right) \rangle$ 后，几何相位有：  
$$\gamma _{n}^{\prime}(t)=\gamma _n(t)-\alpha (\mathbf{R}_f)+\alpha (\mathbf{R}_i)$$
- 对于一个开放路径，总是可以选取一个合适的规范 $\alpha (\mathbf{R})$，使得几何相位为 0
- 即 $\gamma _n(t)=\alpha (\mathbf{R}_f)-\alpha (\mathbf{R}_i)$，$\gamma _{n}^{\prime}(t)=0$，研究相位似乎没有意义了
- 基于该结果，自Vladimir Fock之后的许多研究，一直都忽视了几何相位对系统的影响，直到1984年Michael Berry的文章出现。
# 二、Berry 相位
- 当扰动因其的参数空间路径闭合时，即 $\mathbf{R}_f=\mathbf{R}_i$ 时，情况不一样
- 考虑某一规范变换，有
1. **布洛赫波**：$|\psi _{nk}\rangle =e^{ik\cdot r}|u_{nk}\rangle$，布洛赫波是**扩展**在整个晶体中的。
2. **Wannier函数**：$|w_{n\mathbf{R}}\rangle =V\int_{\mathrm{BZ}}{\frac{\mathrm{d}\mathbf{k}}{(2\pi )^3}\mathrm{e}^{-\mathrm{i}\mathbf{k}\cdot \mathbf{R}}\sum_{m=1}^J{|\boldsymbol{\psi }_{m\mathbf{k}}\rangle U_{mn\mathbf{k}},}}$
- **能量 $E_{nk}$ 是 gauge invariant 的。** 对于每一个k点，布洛赫波 $ψ_{nk}(r)$ 可以乘以一个任意的 $k$ 依赖相位因子 $e^{i\beta(k)}$，而丝毫不改变其物理本质
$$\begin{aligned}
	\langle e^{i\beta (k)}u_{n\mathbf{k}}|H_{\mathbf{k}}|e^{i\beta (k)}u_{n\mathbf{k}}\rangle &=e^{-i\beta (k)}\langle u_{n\mathbf{k}}|H_{\mathbf{k}}|u_{n\mathbf{k}}\rangle e^{i\beta (k)}\\
	&=\langle u_{n\mathbf{k}}|H_{\mathbf{k}}|u_{n\mathbf{k}}\rangle\\
\end{aligned}$$
- **Wannier charge centers： gauge invariant**
- **Berry Phase： gauge invariant**
- **Berry curvature：gauge invariant**
- **Berry联络： gauge dependent**

 
 Maximally localized Wannier functions (MLWFs)
- 尽可能小的展宽

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202601221718726.png)
