- 正常 wannier90 计算，同时 `wannier90.win` 文件要补充以下参数
```
write_xyz = true
```
- 产生文件 `wannier90.dn\up_centres.xyz`  `wannier90.dn\up_hr.dat`  `wannier90.dn\up.win`
- 运行 `wann2J.py --efermi xxx --elements Mn --kmesh 13 13 1 --nz 100 --rcut 10 --np 1  

```
--efermi:  fermi Energy（eV）,
--emax: -the upper limit of the electron energy. Should be close to zero.
--kmesh: k-point mesh. 
--elements： 磁性原子。
--np: 并行的核数。
--nz: 积分的步数. Default: 50
--rcut  range of R. The default is all the commesurate R to the kmesh
--emin  energy minimum below efermi, default -14 eV
  --use_cache   whether to use disk file for temporary storing wavefunctions and hamiltonian to reduce memory
  --cutoff CUTOFF  The minimum of J amplitude to write, (in eV). Default: 1e-7 eV
  --exclude_orbs EXCLUDE_ORBS  the indices of wannier functions to be excluded from magnetic site. counting start from 0. Default is none.
  --description DESCRIPTION add description of the calculatiion to the xml file. Essential information, like the xc functional, U values, magnetic state should be given.
  --orb_decomposition   whether to do orbital decomposition in the non-collinear mode. Default: False.
  ```
## 注意：
1. 检查 WFs 是否局域（`wanier90.wout` 文件中的 `Final State` 的展宽）
	- 通常 $3d$ 轨道的展宽要小于 1 $\AA$
	- $2p$ 轨道展宽小于 2 $\AA$
2. 非共线磁要打开 `--spinor` 和 `--groupby`
	- `--groupby spin`：orb1_up, orb2_up, … orb1_down, orb2_down, …
	- `--groupby orbital`： orb1_up, orb1_down, orb2_up, orb2_down,…
## 读文件：[官网链接](https://tb2j.readthedocs.io/en/latest/src/orbital_contribution.html)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202504031109928.png)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202504031110841.png)
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161040457.png)