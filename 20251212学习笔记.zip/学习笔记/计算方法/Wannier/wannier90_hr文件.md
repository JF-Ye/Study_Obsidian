[利用Wannier90的hr数据构建动量空间能带并计算高对称点宇称 - Yu-Xuan Blog](https://yxli8023.github.io/2021/12/07/HRToHK.html)
```
 written on 27Dec2023 at 11:10:34 
         100    ! num_wann数，能带数， 矩阵维度，跟有多少个轨道跃迁有关
         729	! 格点间的hopping
    2    1    1    1    1    1    2    2    1    1    1    1    1    2    2
    1    1    1    1    1    2    2    1    1    1    1    1    2    2    1
    1    1    1    1    2    2    1    1    1    1    1    2    2    1    1
    1    1    1    2    2    1    1    1    1    1    2    2    1    1    1
    1    1    2    2    1    1    1    1    1    2    2    1    1    1    1
    1    2    2    1    1    1    1    1    2    2    1    1    1    1    1
    2    2    1    1    1    1    1    2    2    1    1    1    1    1    2
    2    1    1    1    1    1    2    2    1    1    1    1    1    2    2
    1    1    1    1    1    2    2    1    1    1    1    1    2    2    1
    1    1    1    1    2    2    1    1    1    1    1    2    2    1    1
    1    1    1    2    2    1    1    1    1    1    2    2    1    1    1
    1    1    2    2    1    1    1 .....（729个数）	！能带兼并情况
   -3   -2   -3    1 Ca-dxy    1 Ca-dxy   0.007585 实部  -0.000000 虚部
   -3   -2   -3    2 Ca-dxy    1 Ca-dxy  -0.002188    0.000000
   -3   -2   -3    3 Ca-dxz   1 Ca-dxy  -0.000922    0.000000
   -3   -2   -3    4 Ca-dxz   1 Ca-dxy   0.000533   -0.000000
   -3   -2   -3    5 Ca-dz2   1 Ca-dxy  -0.000385   -0.000000
   -3   -2   -3    6 Ca-dz2   1 Ca-dxy   0.000649   -0.000000
   -3   -2   -3    7 Ca-dyz   1 ...  -0.029399    0.000000
   -3   -2   -3    8 Ca-dyz   1    0.002602    0.000000
   -3   -2   -3    9 Ca-dx2-y2   1   -0.000000   -0.000000
   -3   -2   -3   10 Ca-dx2-y2   1   -0.000014    0.000000
   -3   -2   -3   11 Pd1-s   1   -0.000050    0.000000
   -3   -2   -3   12 Pd1-s   1    0.000000    0.000000
   -3   -2   -3   13 Pd1-px   1    0.011457   -0.000000
   -3   -2   -3   14 Pd1-px   1   -0.001038   -0.000000
   -3   -2   -3   15 Pd1-pz   1   -0.000000   -0.000000
   -3   -2   -3   16 Pd1-pz   1    0.001176    0.000000
   -3   -2   -3   17 Pd1-py   1   -0.002319   -0.000000
   -3   -2   -3   18 Pd1-py  1    0.000000   -0.000000
   -3   -2   -3   19 Pd1-dxy   1    0.011463   -0.000000
   -3   -2   -3   20 Pd1-dxy   1   -0.001046   -0.000000
   -3   -2   -3   21 Pd1-dxz  1    0.001021    0.000000
   -3   -2   -3   22 Pd1-dxz   1   -0.000589    0.000000
   -3   -2   -3   23 Pd1-dz2   1    0.001107    0.000000
   -3   -2   -3   24 Pd1-dz2   1   -0.001980   -0.000000
   -3   -2   -3   25 Pd1-dyz   1   -0.009142    0.000000
   -3   -2   -3   26 Pd1-dyz   1   -0.000030   -0.000000
   -3   -2   -3   27 Pd1-dx2-y2   1   -0.005518   -0.000000
   -3   -2   -3   28 Pd1-dx2-y2   1    0.000619    0.000000
   -3   -2   -3   29 Pd2-s     1   -0.002643    0.000000
   -3   -2   -3   30 Pd2-s    1 Ca-dxy  -0.002643    0.000000
```
- 前三列表示胞间跃迁，0 0 0 表示原胞， 1 0 0 表示沿 x 轴扩一胞
- 1-100 分别表示：(投影   Ca: d    Pd: s, p, d)
	- 1-10: Ca-dxy, Ca-dxz, Ca-dz2, Ca-dyz, Ca-dx2-y2 (加 soc * 2)
	- 11-12: Pd1-s
	- 13-18: Pd1-px, Pd1-pz, Pd1-py
	- 19-28: Pd1-dxy, Pd1-dxz, Pd1-dz2, Pd1-dyz, Pd1-dx2-y2
	- 29-30: Pd1-s
	- ........
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161040457.png)

公众号计算物理：“如何读取 wannier 90_hr. Dat 文件并将文件中的参数绘图”
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161058741.png)
```
fidt = fopen(hrfile);
fgetl(fidt);

tot_band = str2double(fgetl(fidt));
tot_hp = str2double(fgetl(fidt));
fclose(fidt);

hp_data = readmatrix("phonopyTB_hr.dat","FileType","text","NumHeaderLines",6);

hopping = zeros(1, 3, tot_hp);
for m = 1:tot_hp
hopping(:, :, m) = hp_data(1 + tot_band^2 * (m - 1), 1:3); % 提取了每个hopping的跃迁方向
end

hamiltonian=zeros(tot_band,tot_band,tot_hp);
for m=1:tot_hp
	for n=1:tot_band^2
		hamiltonian(hp_data(n+tot_band^2*(m-1),4),hp_data(n+tot_band^2*(m-1),5),m)=...
		hoppingdata(n+tot_band^2*(m-1),6)+1j*hoppingdata(n+nbands^2*(m-1),7);
		%
	end
end
```
![微信图片_20241216164104.jpg](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202412161641325.jpg)


