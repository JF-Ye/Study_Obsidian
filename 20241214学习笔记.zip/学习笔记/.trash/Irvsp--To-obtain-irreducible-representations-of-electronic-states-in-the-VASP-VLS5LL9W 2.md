---
tags: []
parent: 'Irvsp: To obtain irreducible representations of electronic states in the VASP'
collections:
    - 教科书
version: 0
libraryID: 1
itemKey: VLS5LL9W

---
Irvsp: To obtain irreducible representations of electronic states in the VASP

irreducible representations (IRs) 不可约表示

topological quantum chemistry (TQC)

Bilbao Crystallographic Server (BCS)

high-symmetry k-points (HSK)

character tables (CRTs)

space groups (SGs)

wave-functions (WFs)

matrix presentations (MPs) 矩阵演示

point groups (PNGs)

elementary band representations (EBRs)
