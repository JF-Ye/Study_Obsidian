---
tags: []
parent: 'Crystal net catalog of model flat band materials'
collections:
    - 平带
version: 0
libraryID: 1
itemKey: TP7WW8G9

---
# <span class="highlight" data-annotation="%7B%22attachmentURI%22%3A%22http%3A%2F%2Fzotero.org%2Fusers%2Flocal%2Fw4r2QwTV%2Fitems%2FEDKMSJZI%22%2C%22pageLabel%22%3A%221%22%2C%22position%22%3A%7B%22rects%22%3A%5B%5D%7D%2C%22citationItem%22%3A%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2Flocal%2Fw4r2QwTV%2Fitems%2FT6KI3LKM%22%5D%2C%22locator%22%3A%221%22%7D%7D" ztype="zhighlight"><a href="zotero://open-pdf/library/items/EDKMSJZI?page=NaN">“Crystal net catalog of model flat band materials”</a></span> <span class="citation" data-citation="%7B%22citationItems%22%3A%5B%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2Flocal%2Fw4r2QwTV%2Fitems%2FT6KI3LKM%22%5D%2C%22locator%22%3A%221%22%7D%5D%2C%22properties%22%3A%7B%7D%7D" ztype="zcitation">(<span class="citation-item"><a href="zotero://select/library/items/T6KI3LKM">Neves 等, 2024, p. 1</a></span>)</span> 晶体网平带模型材料目录

# 一、绪论

*   尽管简化了理论模型（只考虑最近邻、单轨道和各向同性），但也有用

*   简单TB模型提供对平带系统的关键指导，且不受SOC、原子种类等因素的影响

*   理论上寻找新的平带模型一般模型：diamond-octagon，Creutz。

*   实验上相反，主要集中在对kagome的研究。因此，需要扩展其他可以实现平带的体系。

    ## 本文主要工作：

    1.  高通量：构建简单紧束缚模型（最近邻、单轨道、均匀hopping）识别非平庸平带体系。

        *   此处定义平庸平带：由隔离的原子引起的平带，不包括任何hopping

    2.  通过crystal net（主要），sublattice graph和能带结构进行分类

# 二、结果讨论

## 搜索结果
