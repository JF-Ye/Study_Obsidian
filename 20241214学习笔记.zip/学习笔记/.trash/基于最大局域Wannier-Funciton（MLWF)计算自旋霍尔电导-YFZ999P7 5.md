---
tags: []
parent: 'Calculation of intrinsic spin Hall conductivity by Wannier interpolation'
collections:
    - 自旋霍尔效应
version: 584
libraryID: 1
itemKey: YFZ999P7

---
# 基于最大局域Wannier Funciton（MLWF)计算自旋霍尔电导

<span class="highlight" data-annotation="%7B%22attachmentURI%22%3A%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2FMVCD5W8P%22%2C%22pageLabel%22%3A%226%22%2C%22position%22%3A%7B%22pageIndex%22%3A5%2C%22rects%22%3A%5B%5B313.54%2C286.993%2C546.664%2C296.119%5D%2C%5B301.579%2C275.207%2C546.656%2C286.191%5D%2C%5B301.578%2C264.079%2C546.657%2C273.205%5D%2C%5B301.579%2C252.622%2C546.655%2C261.748%5D%2C%5B301.579%2C241.165%2C546.671%2C250.291%5D%2C%5B301.579%2C229.708%2C546.643%2C238.834%5D%2C%5B301.579%2C218.251%2C546.663%2C227.377%5D%2C%5B301.578%2C206.794%2C398.486%2C215.92%5D%2C%5B394.261%2C206.794%2C546.653%2C215.92%5D%2C%5B301.579%2C195.337%2C546.668%2C204.463%5D%2C%5B301.579%2C183.88%2C546.661%2C193.006%5D%2C%5B301.579%2C172.423%2C546.642%2C181.549%5D%2C%5B301.579%2C160.966%2C546.655%2C170.092%5D%2C%5B301.579%2C149.509%2C546.669%2C158.635%5D%2C%5B301.579%2C138.052%2C546.659%2C147.178%5D%2C%5B301.579%2C126.595%2C546.638%2C135.721%5D%2C%5B301.579%2C115.138%2C546.662%2C124.264%5D%2C%5B301.579%2C103.681%2C526.146%2C112.807%5D%5D%7D%2C%22citationItem%22%3A%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2FXKDZD68K%22%5D%2C%22locator%22%3A%226%22%7D%7D" ztype="zhighlight"><a href="zotero://open-pdf/library/items/MVCD5W8P?page=6">“Since the calculation of SHC always involves k-point mesh on the order of 1 × 106, special care must be taken with the convergence issues. As shown in Figs. 2 and 3, the rapid variation of SHC usually only occurs at a small portion of the full BZ. In such cases, the method of adaptive k mesh refinement can be very helpful. The convergence of the SHC with respect to the choice of k mesh is presented in Table I. The value of 2281.27 ( ̄ h/e)S/cm from calculation No. 11 is regarded as the fully converged result. Comparing the results for Nos. 1, 2, 3, and 11, we find that the fully converged result can be conveniently obtained by adaptive k mesh refinement even on a not-so-dense BZ grid. Comparing the results from Nos. 4 to 9, it can be concluded that the Wannier interpolation k mesh is the key parameter for the convergence of SHC. Besides, it is noticeable that the density of the original ab initio k mesh has little influence on the convergence of SHC. In the construction process of the MLWF, the ab in”</a></span> <span class="citation" data-citation="%7B%22citationItems%22%3A%5B%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2FXKDZD68K%22%5D%7D%5D%2C%22properties%22%3A%7B%7D%7D" ztype="zcitation">(<span class="citation-item"><a href="zotero://select/library/items/XKDZD68K">Qiao 等, 2018</a></span>)</span>

# 一、绪论

1.   **定义**

    ：SHE指通过施加电场可产生横向自旋电流的现象

2.   **分类**：

    1.  由能带结构直接导致的本征SHE
    2.  与散射相关的外因 side-jump SHE
    3.  与散射相关的外因 skew-scattering SHE

3.  SOC起重要作用

# 二、自选霍尔效应的理论推导

# 三、能算什么？

1.  ## 自旋霍尔电导的大小
2.  ## 自旋霍尔电导与高对称路径的表示图
3.  ## 自旋霍尔电导在第一布里渊区的分布图
撒飞洒登封市