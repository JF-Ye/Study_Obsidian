Irvsp: To obtain irreducible representations of electronic states in the VASP

irreducible representations (IRs) 不可约表示

topological quantum chemistry (TQC)

Bilbao Crystallographic Server (BCS)

high-symmetry k-points (HSK)

character tables (CRTs)

space groups (SGs)

wave-functions (WFs)

matrix presentations (MPs) 矩阵演示

point groups (PNGs)

elementary band representations (EBRs)
