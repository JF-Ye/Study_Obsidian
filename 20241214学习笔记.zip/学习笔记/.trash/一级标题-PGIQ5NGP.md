---
tags: []
parent: 'Unconventional Fermi Surface Instabilities in the Kagome Hubbard Model'
collections:
    - 教科书
version: 664
libraryID: 1
itemKey: PGIQ5NGP

---
# 一级标题

### 三级标题

是东方航空j

**加粗**

*斜体*

<span class="highlight" data-annotation="%7B%22attachmentURI%22%3A%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2FGE8B43PR%22%2C%22annotationKey%22%3A%22INYTEXH3%22%2C%22color%22%3A%22%23ffd400%22%2C%22pageLabel%22%3A%221%22%2C%22position%22%3A%7B%22pageIndex%22%3A0%2C%22rects%22%3A%5B%5B126.199%2C467.998%2C297.029%2C477.412%5D%2C%5B51.931%2C456.036%2C297.013%2C465.45%5D%2C%5B51.931%2C444.074%2C297.03%2C453.489%5D%2C%5B51.931%2C432.112%2C297.048%2C441.527%5D%2C%5B51.931%2C420.15%2C297.044%2C429.565%5D%2C%5B51.931%2C408.189%2C297.013%2C417.603%5D%2C%5B51.931%2C396.227%2C297.045%2C405.641%5D%2C%5B51.931%2C384.265%2C297.005%2C393.68%5D%2C%5B51.931%2C372.36%2C297.01%2C381.774%5D%2C%5B51.931%2C360.398%2C297.051%2C369.812%5D%2C%5B51.931%2C348.436%2C297.026%2C357.851%5D%2C%5B51.931%2C336.474%2C297.046%2C345.889%5D%2C%5B51.931%2C324.512%2C297.047%2C333.927%5D%2C%5B51.931%2C312.551%2C297.015%2C321.965%5D%2C%5B51.931%2C300.589%2C297.067%2C310.003%5D%2C%5B51.931%2C288.627%2C297.023%2C298.042%5D%2C%5B51.931%2C276.722%2C297.045%2C286.136%5D%2C%5B51.931%2C264.76%2C280.379%2C274.174%5D%5D%7D%2C%22citationItem%22%3A%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2F3XEB9QNE%22%5D%2C%22locator%22%3A%221%22%7D%7D" ztype="zhighlight"><a href="zotero://open-pdf/library/items/GE8B43PR?page=1&#x26;annotation=INYTEXH3">“The interplay of fermiology and interactions gives rise to a plethora of ordering phenomena in twodimensional electron systems. Starting from an itinerant electron picture, the density of states (DOS) at low energies around the Fermi level as well as nesting features of the Fermi surface are the relevant parameters of the kinetic theory. In the limit of weak interactions imposed on the noninteracting electrons where a perturbative treatment is asymptotically exact, superconducting order as a phasecoherent superposition of Cooper pairs is the generically encountered Fermi surface instability [1]. This situation can be changed in various different ways: By enhancing the interaction scale or via nesting and enlarged DOS at the Fermi level, order due to condensation of particle-hole pairs can become competitive and even favorable to superconductivity. Prominent examples include magnetic (charge) order via a spin (charge) density wave which can induce superconductivity as a function of doping or pressure.”</a></span> <span class="citation" data-citation="%7B%22citationItems%22%3A%5B%7B%22uris%22%3A%5B%22http%3A%2F%2Fzotero.org%2Fusers%2F14064744%2Fitems%2F3XEB9QNE%22%5D%7D%5D%2C%22properties%22%3A%7B%7D%7D" ztype="zcitation">(<span class="citation-item"><a href="zotero://select/library/items/3XEB9QNE">Kiesel 等, 2013</a></span>)</span> 🔤费米学和相互作用的相互作用导致了二维电子系统中大量的有序现象。从巡回电子图景出发，费米级附近低能状态密度（DOS）以及费米面的嵌套特征是动力学理论的相关参数。在对非相互作用电子施加微扰处理近似精确的弱相互作用极限下，作为库珀对相干叠加的超导阶是通常遇到的费米面不稳定性\[1]。这种情况可以通过各种不同的方式改变：通过增强相互作用尺度或通过嵌套和扩大费米级的 DOS，粒子-空穴对的凝聚所产生的有序可以变得有竞争力，甚至有利于超导。突出的例子包括通过自旋（电荷）密度波产生的磁性（电荷）有序，它可以作为掺杂或压力的函数诱发超导。🔤

# 以及

sdf

![\<img alt="" data-attachment-key="P9ZBXAUP" width="540" height="292" src="attachments/P9ZBXAUP.png" ztype="zimage">](attachments/P9ZBXAUP.png)
