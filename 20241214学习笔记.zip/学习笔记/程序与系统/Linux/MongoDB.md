- 先安装 `mongosh`
- 外部连接命令
```
./mongosh "mongodb://root:zjm412@10.129.139.159:27017/?authSource=admin"
Current Mongosh Log ID:	6724b8ccf469e05e9ac1c18b
```
- IP: `10.129.139.159`
- 端口：`27017`
- 用户名：`admin`
- 密码：`zjm412`