# 加 U
- LDAU= .TRUE.|. FALSE.：开启/关闭+U 功能，默认值为. FALSE.
- LDAUTYPE=1|2|4 指的是+U 的类型，默认值是 2；其中 1 为 Liechtenstein 等提出的旋转不变 LSDA+U 方法；2 为 Dudarev 等提出的简化 LSDA+U 方法；4 与 1 类似, 但不考虑 LSDA 交换劈裂；
- LDAUL=-1|1|2|3 分别对应不加 U、p、d、f 轨道加 U
- LDAUU、LDAUJ 分别指定电子库伦相互作用项和交换相互作用项（U 和 J 值）；
- LMAXMIX =2/4/6：默认为 2，加 U 计算时该值需大于轨道量子数，对于含有 d 轨道或 f 轨道电子的体系需对应增加至 4 或 6。
```
LDAU    = .TRUE.
LDAUTYPE= 2
LDAUL   = -1 2 -1
LDAUU   = 0 4.0  0
LDAUJ   = 0.0 0 0
LDAUPRINT = 2
LMAXMIX = 4
```
# 非共线磁性
```
ISPIN = 2
LNONCOLLINEAR = .TRUE.
MAGMOM = ***** # 笛卡尔坐标，即直角坐标系
```