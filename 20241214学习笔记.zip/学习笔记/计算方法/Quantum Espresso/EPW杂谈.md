1. `.a2f` 文件末尾的电声耦合强度于温度参数 `temps` 无关
2. 初步预测有没有潜力做超导，epw.out 文件
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202409140923703.png)
