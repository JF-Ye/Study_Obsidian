# QE 
- 官方参数总览：[input data description](https://www.quantum-espresso.org/documentation/input-data-description/)
- `pw.in` 官方参数：[点击这里](https://www.quantum-espresso.org/Doc/INPUT_PW.html)
- QE 官方 GitHub 示例：[点击这里](https://github.com/quantumNerd/Quantum-Espresso-Tutorial-2019-Projects)
- 教程 1：[Theory using Quantum Espresso • Quantum Espresso Tutorial](https://pranabdas.github.io/espresso/)
- 教程 2：[qe-study](https://github.com/nawu97/qe-study/blob/main/%E6%94%B6%E6%95%9B%E9%97%AE%E9%A2%98.md)
- QE 实践详解教程：[QE实践详解 - DFTbook (yyyu200.github.io)](https://yyyu200.github.io/DFTbook/blogs/2019/04/01/HandsOn/#4-%E5%A3%B0%E5%AD%90%E8%B0%B1%E7%9A%84%E8%AE%A1%E7%AE%97)
- 准备 **KPOINTS, POSCAR** 文件，**vaspkit-416**  生成 pwscf.in 文件
# EPW
- 官网：[EPW Software (epw-code.org)](https://epw-code.org/)
- 官网 school 有很多具体例子：[Summer School 2024 — EPW documentation](https://docs.epw-code.org/doc/School2024.html)
- 学习资料文件夹：E:\\学习资料\\QE\\EPW summer school
- 教程：[QUANTUM ESPRESSO：EPW - 谢华的博客 | Xiehua's Blog (xh125.github.io)](https://xh125.github.io/2021/12/16/QE-epw/)
- 教程 2：[qe-study](https://github.com/nawu97/qe-study/blob/main/Wed.4.Verdi.pdf)
- 官网参数说明：[点击这里](https://docs.epw-code.org/doc/Inputs.html#inputepw)
- 能做什么？
> 	1. 超导特性
> 	2. 不同温度下的能带结构
> 	3. 输运性质和热载流子动力学