1. 高精度弛豫
2. 计算费米面
	- INCAR 参数与自洽计算一致
	- vaspkit-261 生成计算费米面的 KPOINTS
3. 运行计算
4. vaspkit-262 生成包含费米面数据的`FERMISURFACE.bxsf`文件