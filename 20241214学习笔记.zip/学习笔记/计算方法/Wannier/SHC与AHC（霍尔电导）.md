```
&CONTROL
AHC_calc=T     ! 反常霍尔电导
SHC_calc=T     ！自旋霍尔电导
/

&PARAMETERS
OmegaNum = 601    ! number of slices of energy
OmegaMin = -1.0   ! erergy range for AHC
OmegaMax =  1.0
Nk1 = 51   ! No. of slices for the 1st reciprocal vector
Nk2 = 51   ! No. of slices for the 2nd reciprocal vector
Nk3 = 51   ! No. of slices for the 3nd reciprocal vector
/

KCUBE_BULK
  0.00  0.00  0.00   ! Original point for 3D k plane
  1.00  0.00  0.00   ! The first vector 
  0.00  1.00  0.00   ! The second vector
  0.00  0.00  1.00   ! The third vector
```
![Cache_-8cb3158e7529cc.jpg](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411071720390.jpg)
S：西门子
$\Omega$ : 欧姆，$\Omega=1/S$ 

![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411071949163.png)
- Gigantic intrinsic orbital Hall effects in weakly spin-orbit coupled metals
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411072259145.png)
- Universal Intrinsic Spin Hall Effect
![image.png](https://jf-1325624113.cos.ap-guangzhou.myqcloud.com/study_picture/202411080951208.png)
- Calculation of intrinsic spin Hall conductivity by Wannier interpolation