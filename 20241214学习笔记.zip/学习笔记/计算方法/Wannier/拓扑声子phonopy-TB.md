- 需要 python 2
- Phonopy 版本：1.11.8
# 一、生成 `phonopyTB_hr.dat`
1. 更改环境变量 `vi ~/.bashrc`，`source ~/.bashrc`
```
__conda_setup="$('/root/anaconda2/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
    eval "$__conda_setup"
else
    if [ -f "/root/anaconda2/etc/profile.d/conda.sh" ]; then
        . "/root/anaconda2/etc/profile.d/conda.sh"
    else
        export PATH="/root/anaconda2/bin:$PATH"
    fi
fi
unset __conda_setup
```
2. PhonopyTB 路径：`/root/solf/wannier_tools-2.7.0/utility/phonopyTB`
3. 准备文件：`POSCAR-unitcell`, `FORCE_CONSTANTS`, `band.conf`
```band_conf
ATOM_NAME = Ca Pd 
DIM = 2 2 2
FORCE_CONSTANTS = READ
FC_SYMMETRY = 1
fc_spg_symmetry = .true.
```
4. 运行命令：`python phonon_hr.py -d --dim="3 3 3" -c POSCAR-unitcell -p band.conf`（服务器环境变量好像有问题，要绝对路径运行）
# 二、`wt.x` 运行
准备 `wt.in` 文件
- `Hrfile = 'phonopyTB_hr.dat'
- `Particle = 'phonon' `
- `PROJECTORS`：全部改为 `px py pz`
- `E_arc`：单位为 THz，不用转换成 eV
- `SOC`：改为 0
```
&TB_FILE
Hrfile = 'phonopyTB_hr.dat'
Particle = 'phonon'
/


ATOM_MASS
2  ! number of types of atom, for FeSi, we have 2
1 5  ! number of atoms for each atom-type Fe4Si4
40.078  106.42 


LATTICE
Angstrom
5.291046  0.000000  0.000000
-2.645523  4.582180  0.000000
0.000000  0.000000  4.440557

ATOM_POSITIONS
6
Direct
Ca  0.00000  0.00000  0.00000
Pd  0.33333  0.66667  0.00000
Pd  0.66667  0.33333  0.00000
Pd  0.00000  0.50000  0.50000
Pd  0.50000  0.00000  0.50000
Pd  0.50000  0.50000  0.50000

PROJECTORS
3 3 3 3 3 3
Ca px py pz 
Pd px py pz
Pd px py pz
Pd px py pz
Pd px py pz
Pd px py pz

SURFACE
1 0 0
0 1 0

&CONTROL
BulkBand_calc         = F
SlabBand_calc         = F
SlabSS_calc           = T
SlabArc_calc          = T
WeylChirality_calc    = F
BerryCurvature_calc   = T
LOTO_correction       = F
/

&SYSTEM
NSLAB = 10
NSLAB1 = 4
NSLAB2 = 4
NumOccupied = 15
SOC = 0
/

```