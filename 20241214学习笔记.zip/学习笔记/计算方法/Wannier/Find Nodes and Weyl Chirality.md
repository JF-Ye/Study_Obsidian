# Find Nodes
```
&CONTROL
FindNodes_calc = T
/
&PARAMETERS
Nk1 = 8   ! No. of slices for the 1st reciprocal vector
Nk2 = 8   ! No. of slices for the 2nd reciprocal vector
Nk3 = 8   ! No. of slices for the 3rd reciprocal vector
Gap_threshold = 0.0001 ! 两能带间的gap小于这个值会被认为是一对nodes
/

KCUBE_BULK
-0.50 -0.50 -0.50   ! Original point for 3D k plane
 1.00  0.00  0.00   ! The 1st vector to define 3d k cube
 0.00  1.00  0.00   ! The 2nd vector to define 3d k cube
 0.00  0.00  1.00   ! The 3rd vector to define 3d k cube
```
# Weyl 手性
```
&CONTROL
WeylChirality_calc = T
/
&PARAMETERS
Nk1 = 41   ! No. of slices for the 1st reciprocal vector, berry phase integration direction
Nk2 = 21   ! No. of slices for the 2nd reciprocal vector
/

WEYL_CHIRALITY
8            ! Num_Weyls
Cartesian    ! Direct or Cartesian coordinate
0.004        ! Radius of the ball surround a Weyl point
 0.219436   -0.045611   -0.000000    ! Positions of Weyl points, kx, ky, kz
-0.219515   -0.045063   -0.000000
 0.220195   -0.038682   -0.000000
-0.220183   -0.038936   -0.000000
 0.219514    0.045063    0.000000
-0.219434    0.045620    0.000000
-0.220194    0.038678    0.000000
 0.220181    0.038941    0.000000
```